# Fuentes del Entregable 5 de Santa Cecilia

Este paquete reúne el código y la evidencia disponible para redactar Lógica de Negocio y Servicios de Seminario de Tesis II. Abrir primero Inventario_Logica_Negocio.md, que contiene las fichas de clase, DTOs, endpoints, reglas, errores y límites.

## Resumen del contenido

| Grupo | Archivos recopilados |
|---|---|
| Capturas históricas con datos sintéticos | 7 |
| Configuración estructural sin secretos | 4 |
| Código Java del backend | 58 |
| Documentos solicitados | 5 |
| Fuentes de pruebas Android/JVM existentes | 5 |
| Informes técnicos de verificaciones anteriores | 5 |
| Inventario y trazabilidad | 5 |
| Manifiestos y sumas SHA-256 | 3 |
| Migraciones y protocolo SQL | 9 |
| Resultados JVM saneados | 2 |
| Resultados y resúmenes históricos | 7 |

**Total: 110 archivos.** El inventario y trazabilidad incluyen este README. Los manifiestos enumeran las fuentes y documentos derivados; SHA256SUMS.txt cubre todos los archivos del ZIP salvo a sí mismo.

## Cómo verificar y recorrer las fuentes

1. Revisar las fichas por clase y el catálogo de 59 rutas implementadas.
2. Abrir backend/src/main/java/com/santacecilia/api/ para comprobar nombres, métodos, validaciones y transacciones.
3. Consultar los cinco Markdown solicitados en sus rutas originales y las siete migraciones que respaldan las restricciones SQL.
4. Revisar los JSON históricos, XML saneados y capturas junto con sus límites. No convertir el contenido de una lista de checks en nombres de tests JUnit inexistentes.
5. Usar MANIFIESTO_ARCHIVOS.csv/JSON y SHA256SUMS.txt para identificar archivos y copias saneadas.

## Interpretación de pagos

La app registra pagos externos por Yape, Plin y transferencia. Un administrador contrasta el ingreso y ejecuta su conciliación. La reserva se crea automáticamente como efecto interno del primer abono aplicable. No hay pasarela comercial, webhook bancario, cobro automático ni devolución bancaria ejecutada por el servidor. Las imágenes y los ingresos de las pruebas incluidas son sintéticos.

## Exclusiones y límites

No se incluyen archivos .env, claves privadas, credenciales ni tokens de ejecución. Los nombres de campos/DTOs necesarios para explicar autenticación se conservan. Se omitieron datos de perfil y hostname de los reportes que lo requerían. No se copiaron la base habitual, usuarios, pagos reales, Office con portadas personales, logs completos, ejecutables, dependencias o auxiliares privados de pruebas.

No se ejecutaron nuevas pruebas del negocio ni se alteraron Android/backend. No se hicieron commits, push ni merge. Este es un paquete de fuentes y evidencias, no un despliegue listo para producción ni el proyecto completo para compilar de forma autónoma. Los resultados locales no acreditan rendimiento o satisfacción con usuarios.
