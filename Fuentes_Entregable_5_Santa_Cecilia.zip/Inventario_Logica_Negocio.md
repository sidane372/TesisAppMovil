# Inventario de lógica de negocio de Santa Cecilia

**Asignatura:** Seminario de Tesis II, Unidad III, Entregable 5. **Corte de recopilación:** 2026-11-04T22:40:23-05:00.

**Base de código:** repositorio TesisAppMovil; rama `main`; HEAD `526df8eff10021079d39c5f459e9fd4bed95dd8c`. El inventario se obtiene de archivos locales y no implica un nuevo commit.

Se incluyen **58 archivos Java**, **94 tipos declarados** contando records y tipos anidados, y **59 combinaciones de verbo y ruta REST** extraídas de anotaciones. El parser Java se utilizó solo para análisis sintáctico; no es una nueva compilación o ejecución del backend.

## 1 Criterios de interpretación

- El código fuente define las clases, métodos y endpoints efectivamente implementados. Los documentos anteriores se conservan como fuentes históricas y pueden contener párrafos superados.
- Implementado significa presente en código y con el alcance descrito. No equivale a aprobación de todos los RF/RNF ni a despliegue productivo.
- Se distinguen entidades JPA, records DTO y registros SQL manipulados como Map. No existen clases JPA llamadas Contrato, Cotizacion, Pago o Reserva en estos fuentes.
- Los nombres de campos password/token y los algoritmos de validación forman parte del código; no se incluyen contraseñas, tokens de ejecución ni filas de la base.
- Las evidencias de pagos y sus capturas corresponden a datos sintéticos locales, no a operaciones bancarias reales ni a un sandbox oficial.

## 2 Resumen de clases por paquete

| Paquete | Archivos Java principales |
|---|---|
| com.santacecilia.api | 1 |
| com.santacecilia.api.audit | 1 |
| com.santacecilia.api.config | 5 |
| com.santacecilia.api.controller | 8 |
| com.santacecilia.api.dto | 9 |
| com.santacecilia.api.entity | 7 |
| com.santacecilia.api.exception | 4 |
| com.santacecilia.api.repository | 8 |
| com.santacecilia.api.security | 6 |
| com.santacecilia.api.service | 9 |

El paquete `service` contiene nueve archivos, incluido `RecoveryMailSender`, que es un componente de correo. `AuditoriaService` se encuentra en `audit`. La clasificación se refiere al paquete real, no a un número supuesto de anotaciones @Service.

## 3 Inventario por clase

| Clase | Paquete | Responsabilidad | Estado | Fuente |
|---|---|---|---|---|
| SantaCeciliaApiApplication | com.santacecilia.api | Arrancar Spring Boot y declarar servicios básicos. | Implementado | [Java, L8](backend/src/main/java/com/santacecilia/api/SantaCeciliaApiApplication.java#L8) |
| AuditoriaService | com.santacecilia.api.audit | Registrar auditoría de operaciones en MySQL. | Registro implementado; interfaz general de auditoría pendiente | [Java, L5](backend/src/main/java/com/santacecilia/api/audit/AuditoriaService.java#L5) |
| AdministradorInicial | com.santacecilia.api.config | Crear una primera cuenta administrativa de forma explícita. | Implementado; secretos excluidos del paquete | [Java, L14](backend/src/main/java/com/santacecilia/api/config/AdministradorInicial.java#L14) |
| CorrelationFilter | com.santacecilia.api.config | Asignar identificador de correlación a la petición. | Implementado | [Java, L10](backend/src/main/java/com/santacecilia/api/config/CorrelationFilter.java#L10) |
| CorreoConfig | com.santacecilia.api.config | Proveer executor acotado para envío de recuperación. | Implementado | [Java, L4](backend/src/main/java/com/santacecilia/api/config/CorreoConfig.java#L4) |
| PagosPrivadosFilter | com.santacecilia.api.config | Limitar cuerpos de comprobantes y evitar su caché. | Implementado | [Java, L12](backend/src/main/java/com/santacecilia/api/config/PagosPrivadosFilter.java#L12) |
| SecurityConfig | com.santacecilia.api.config | Configurar autenticación, roles, filtros y respuesta de seguridad. | Implementado; no certifica seguridad productiva | [Java, L17](backend/src/main/java/com/santacecilia/api/config/SecurityConfig.java#L17) |
| AdminServicioController | com.santacecilia.api.controller | Exponer las rutas REST declaradas y delegar en ServicioService. | Controller implementado; no acredita validación productiva | [Java, L10](backend/src/main/java/com/santacecilia/api/controller/AdminServicioController.java#L10) |
| AdminUsuarioController | com.santacecilia.api.controller | Exponer las rutas REST declaradas y delegar en UsuarioService. | Controller implementado; no acredita validación productiva | [Java, L10](backend/src/main/java/com/santacecilia/api/controller/AdminUsuarioController.java#L10) |
| AuthController | com.santacecilia.api.controller | Exponer las rutas REST declaradas y delegar en AuthService, RecoveryService. | Controller implementado; no acredita validación productiva | [Java, L12](backend/src/main/java/com/santacecilia/api/controller/AuthController.java#L12) |
| ContratacionController | com.santacecilia.api.controller | Exponer las rutas REST declaradas y delegar en ContratacionService. | Controller implementado; no acredita validación productiva | [Java, L16](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L16) |
| EstadoController | com.santacecilia.api.controller | Exponer las rutas REST declaradas y delegar en JdbcTemplate. | Controller implementado; no acredita validación productiva | [Java, L6](backend/src/main/java/com/santacecilia/api/controller/EstadoController.java#L6) |
| PagoDirectoController | com.santacecilia.api.controller | Exponer las rutas REST declaradas y delegar en PagoDirectoService. | Controller implementado; no acredita validación productiva | [Java, L13](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L13) |
| ServicioController | com.santacecilia.api.controller | Exponer las rutas REST declaradas y delegar en ServicioService. | Controller implementado; no acredita validación productiva | [Java, L11](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L11) |
| UsuarioController | com.santacecilia.api.controller | Exponer las rutas REST declaradas y delegar en UsuarioService. | Controller implementado; no acredita validación productiva | [Java, L9](backend/src/main/java/com/santacecilia/api/controller/UsuarioController.java#L9) |
| ApiResponse | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L2](backend/src/main/java/com/santacecilia/api/dto/ApiResponse.java#L2) |
| AuthDtos | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L4](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L4) |
| CambioConMotivo | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L3](backend/src/main/java/com/santacecilia/api/dto/CambioConMotivo.java#L3) |
| ContratacionDtos | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L9](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L9) |
| Pagina | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L3](backend/src/main/java/com/santacecilia/api/dto/Pagina.java#L3) |
| PagoDirectoDtos | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L7](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L7) |
| ServicioDtos | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L4](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L4) |
| UsuarioDtos | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L5](backend/src/main/java/com/santacecilia/api/dto/UsuarioDtos.java#L5) |
| UsuarioResponse | com.santacecilia.api.dto | Definir entradas o salidas de la API sin exponer entidades completas. | Contrato de datos implementado | [Java, L3](backend/src/main/java/com/santacecilia/api/dto/UsuarioResponse.java#L3) |
| FamiliaSesion | com.santacecilia.api.entity | Representar auth_familia en el modelo Java. | Entidad o enum implementado; no se incluyen registros de personas | [Java, L4](backend/src/main/java/com/santacecilia/api/entity/FamiliaSesion.java#L4) |
| RecuperacionAcceso | com.santacecilia.api.entity | Representar recuperacion_acceso en el modelo Java. | Entidad o enum implementado; no se incluyen registros de personas | [Java, L4](backend/src/main/java/com/santacecilia/api/entity/RecuperacionAcceso.java#L4) |
| Rol | com.santacecilia.api.entity | Representar los cuatro roles mediante un enum Java. | Enum implementado | [Java, L2](backend/src/main/java/com/santacecilia/api/entity/Rol.java#L2) |
| ServicioMusical | com.santacecilia.api.entity | Representar servicio_musical en el modelo Java. | Entidad o enum implementado; no se incluyen registros de personas | [Java, L4](backend/src/main/java/com/santacecilia/api/entity/ServicioMusical.java#L4) |
| Sesion | com.santacecilia.api.entity | Representar sesion en el modelo Java. | Entidad o enum implementado; no se incluyen registros de personas | [Java, L4](backend/src/main/java/com/santacecilia/api/entity/Sesion.java#L4) |
| TokenAcceso | com.santacecilia.api.entity | Representar token_acceso en el modelo Java. | Entidad o enum implementado; no se incluyen registros de personas | [Java, L4](backend/src/main/java/com/santacecilia/api/entity/TokenAcceso.java#L4) |
| Usuario | com.santacecilia.api.entity | Representar usuario en el modelo Java. | Entidad o enum implementado; no se incluyen registros de personas | [Java, L4](backend/src/main/java/com/santacecilia/api/entity/Usuario.java#L4) |
| ApiError | com.santacecilia.api.exception | Definir el contrato JSON de error. | Record implementado | [Java, L3](backend/src/main/java/com/santacecilia/api/exception/ApiError.java#L3) |
| ApiException | com.santacecilia.api.exception | Representar errores de negocio con estado y código. | Implementado | [Java, L3](backend/src/main/java/com/santacecilia/api/exception/ApiException.java#L3) |
| GlobalExceptionHandler | com.santacecilia.api.exception | Traducir excepciones a respuestas HTTP seguras. | Implementado; filtros pueden responder fuera de este contrato | [Java, L13](backend/src/main/java/com/santacecilia/api/exception/GlobalExceptionHandler.java#L13) |
| TokenRejectedException | com.santacecilia.api.exception | Representar rechazo de sesión que no revierte la revocación de familia. | Implementado | [Java, L4](backend/src/main/java/com/santacecilia/api/exception/TokenRejectedException.java#L4) |
| ContenidoServicioRepository | com.santacecilia.api.repository | Persistir listas normalizadas y repertorio de servicios. | Implementado para contenido descrito | [Java, L6](backend/src/main/java/com/santacecilia/api/repository/ContenidoServicioRepository.java#L6) |
| ContratacionRepository | com.santacecilia.api.repository | Acceso JDBC parametrizado y protocolo de recursos compartidos. | Implementado; garantía depende de transacción del Service | [Java, L13](backend/src/main/java/com/santacecilia/api/repository/ContratacionRepository.java#L13) |
| FamiliaSesionRepository | com.santacecilia.api.repository | Bloquear familias y revocar sesiones de un usuario. | Implementado | [Java, L7](backend/src/main/java/com/santacecilia/api/repository/FamiliaSesionRepository.java#L7) |
| RecuperacionRepository | com.santacecilia.api.repository | Buscar enlaces de recuperación por hash e invalidarlos. | Implementado | [Java, L6](backend/src/main/java/com/santacecilia/api/repository/RecuperacionRepository.java#L6) |
| ServicioRepository | com.santacecilia.api.repository | Consultar servicios propios, publicados y filas para actualización. | Implementado | [Java, L7](backend/src/main/java/com/santacecilia/api/repository/ServicioRepository.java#L7) |
| SesionRepository | com.santacecilia.api.repository | Buscar la sesión por hash del refresh. | Implementado | [Java, L5](backend/src/main/java/com/santacecilia/api/repository/SesionRepository.java#L5) |
| TokenAccesoRepository | com.santacecilia.api.repository | Buscar un token de acceso por su hash. | Implementado | [Java, L5](backend/src/main/java/com/santacecilia/api/repository/TokenAccesoRepository.java#L5) |
| UsuarioRepository | com.santacecilia.api.repository | Consultar usuarios y bloquear identidad para escrituras. | Implementado | [Java, L6](backend/src/main/java/com/santacecilia/api/repository/UsuarioRepository.java#L6) |
| AuthPrincipal | com.santacecilia.api.security | Transportar identidad autorizada dentro del servidor. | Record implementado | [Java, L3](backend/src/main/java/com/santacecilia/api/security/AuthPrincipal.java#L3) |
| BearerAuthenticationFilter | com.santacecilia.api.security | Resolver Authorization Bearer a una identidad autenticada. | Implementado | [Java, L13](backend/src/main/java/com/santacecilia/api/security/BearerAuthenticationFilter.java#L13) |
| RequestThrottle | com.santacecilia.api.security | Limitar intentos de acceso en la instancia local. | Implementado por instancia; coordinación distribuida pendiente | [Java, L8](backend/src/main/java/com/santacecilia/api/security/RequestThrottle.java#L8) |
| StrongPassword | com.santacecilia.api.security | Declarar la validación de contraseña del dominio. | Anotación implementada | [Java, L4](backend/src/main/java/com/santacecilia/api/security/StrongPassword.java#L4) |
| StrongPasswordValidator | com.santacecilia.api.security | Verificar longitud y caracteres de la contraseña recibida. | Implementado | [Java, L4](backend/src/main/java/com/santacecilia/api/security/StrongPasswordValidator.java#L4) |
| TokenCodec | com.santacecilia.api.security | Generar valores opacos y calcular hash de credenciales temporales. | Implementado; no se incluyen valores de ejecución | [Java, L6](backend/src/main/java/com/santacecilia/api/security/TokenCodec.java#L6) |
| AuthService | com.santacecilia.api.service | Registrar clientes y administrar sesiones opacas. | Implementado localmente | [Java, L16](backend/src/main/java/com/santacecilia/api/service/AuthService.java#L16) |
| ComprobanteImagenService | com.santacecilia.api.service | Validar y recodificar imágenes de comprobantes. | Implementado localmente | [Java, L14](backend/src/main/java/com/santacecilia/api/service/ComprobanteImagenService.java#L14) |
| ContratacionService | com.santacecilia.api.service | Solicitudes, cotizaciones, contratos y agenda. | Implementado localmente dentro de esas transiciones | [Java, L24](backend/src/main/java/com/santacecilia/api/service/ContratacionService.java#L24) |
| PagoAvisosService | com.santacecilia.api.service | Entregar outbox de pago a notificaciones internas. | Procesamiento interno implementado; bandeja visible pendiente | [Java, L17](backend/src/main/java/com/santacecilia/api/service/PagoAvisosService.java#L17) |
| PagoDirectoService | com.santacecilia.api.service | Pagos directos, comprobantes, conciliación y seguimiento de devoluciones. | Implementado como conciliación humana; sin pasarela automática | [Java, L28](backend/src/main/java/com/santacecilia/api/service/PagoDirectoService.java#L28) |
| RecoveryMailSender | com.santacecilia.api.service | Preparar y enviar correo de recuperación tras el commit. | Implementado; SMTP real no acreditado | [Java, L9](backend/src/main/java/com/santacecilia/api/service/RecoveryMailSender.java#L9) |
| RecoveryService | com.santacecilia.api.service | Solicitar recuperación y restablecer contraseña. | Implementado; operación externa condicionada a SMTP | [Java, L15](backend/src/main/java/com/santacecilia/api/service/RecoveryService.java#L15) |
| ServicioService | com.santacecilia.api.service | Catálogo, publicación, tarifa y repertorio de servicios. | Implementado en catálogo y repertorio; imágenes/integrantes incompletos | [Java, L15](backend/src/main/java/com/santacecilia/api/service/ServicioService.java#L15) |
| UsuarioService | com.santacecilia.api.service | Gestionar cuentas, perfil y estado administrativo. | Implementado localmente | [Java, L16](backend/src/main/java/com/santacecilia/api/service/UsuarioService.java#L16) |

### SantaCeciliaApiApplication

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | SantaCeciliaApiApplication |
| Paquete | com.santacecilia.api |
| Responsabilidad | Arrancar Spring Boot y declarar servicios básicos. |
| Métodos principales | `main(String[] args)` (L10); `clock()` (L11); `passwordEncoder()` (L12) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | SpringApplication, Clock y PasswordEncoder. |
| Validaciones | Configuración de Spring y beans. |
| Reglas de negocio | Clock UTC y BCryptPasswordEncoder con coste 12. |
| Errores controlados | Errores de arranque no son respuestas de un Controller. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/SantaCeciliaApiApplication.java#L8) |

### AuditoriaService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | AuditoriaService |
| Paquete | com.santacecilia.api.audit |
| Responsabilidad | Registrar auditoría de operaciones en MySQL. |
| Métodos principales | `registrar(Long actor, String entidad, Object id, String accion, String detalle)` (L9) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tabla historial_operacion mediante JdbcTemplate. |
| Validaciones | Parámetros SQL enlazados; sin validación HTTP propia. |
| Reglas de negocio | Guarda actor, entidad, identificador, acción, detalle JSON y correlation_id; se invoca desde las transacciones del negocio. |
| Errores controlados | Propaga errores de persistencia al llamador; manejador global si ocurre durante una petición. |
| Estado de implementación | Registro implementado; interfaz general de auditoría pendiente |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/audit/AuditoriaService.java#L5) |

### AdministradorInicial

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | AdministradorInicial |
| Paquete | com.santacecilia.api.config |
| Responsabilidad | Crear una primera cuenta administrativa de forma explícita. |
| Métodos principales | `run(String... args)` (L24) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | Usuario, Rol y UsuarioRepository. |
| Validaciones | Validator sobre CrearMusico y ausencia de correo previo; variables externas. |
| Reglas de negocio | Solo si app.bootstrap.enabled=true y no existe ADMIN; no eleva una cuenta previa; guarda bcrypt. |
| Errores controlados | IllegalStateException en arranque si configuración inválida, no endpoint HTTP. |
| Estado de implementación | Implementado; secretos excluidos del paquete |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/config/AdministradorInicial.java#L14) |

### CorrelationFilter

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | CorrelationFilter |
| Paquete | com.santacecilia.api.config |
| Responsabilidad | Asignar identificador de correlación a la petición. |
| Métodos principales | `doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)` (L12) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | Sin entidad; soporte de ApiError. |
| Validaciones | Sin validación del negocio. |
| Reglas de negocio | Genera UUID, atributo correlationId y cabecera X-Correlation-Id. |
| Errores controlados | Propaga ServletException/IOException; no código HTTP propio. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/config/CorrelationFilter.java#L10) |

### CorreoConfig

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | CorreoConfig |
| Paquete | com.santacecilia.api.config |
| Responsabilidad | Proveer executor acotado para envío de recuperación. |
| Métodos principales | `correoExecutor()` (L6) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | ThreadPoolTaskExecutor. |
| Validaciones | Configuración del bean correoExecutor. |
| Reglas de negocio | Pool mínimo 2, máximo 4, cola 100; prefijo de hilo sc-correo-. |
| Errores controlados | La saturación se controla en RecoveryMailSender; no HTTP propio. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/config/CorreoConfig.java#L4) |

### PagosPrivadosFilter

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | PagosPrivadosFilter |
| Paquete | com.santacecilia.api.config |
| Responsabilidad | Limitar cuerpos de comprobantes y evitar su caché. |
| Métodos principales | `doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)` (L16) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | HttpServletRequestWrapper y ServletInputStream; sin entidad. |
| Validaciones | Content-Length y contador de bytes en lectura del cuerpo. |
| Reglas de negocio | Cabeceras no-store/no-cache en rutas de pago/admin; límite de 3 MB antes de deserializar. |
| Errores controlados | 413 con sendError si longitud declarada excede límite; el corte de stream lanza IOException. No garantiza el mismo cuerpo ApiError en todos los fallos. |
| Estado de implementación | Implementado |
| Evidencia disponible | [28 comprobaciones agrupadas, sintéticas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/pagos_comprobaciones_sinteticas.json); [informe](docs/pagos_arquitectura.md); [fuente original](backend/src/main/java/com/santacecilia/api/config/PagosPrivadosFilter.java#L12) |

### SecurityConfig

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | SecurityConfig |
| Paquete | com.santacecilia.api.config |
| Responsabilidad | Configurar autenticación, roles, filtros y respuesta de seguridad. |
| Métodos principales | `chain(HttpSecurity http, AuthService auth, ObjectMapper json)` (L19); `userDetails(UsuarioRepository users)` (L35) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | AuthService, UsuarioRepository, AuthPrincipal y ApiError. |
| Validaciones | Reglas de URL y UserDetailsService; rol real obtenido de servidor. |
| Reglas de negocio | HTTP stateless, sin formulario/basic; rutas públicas limitadas; /admin/** exige ADMINISTRADOR; el resto autenticado; CSP. |
| Errores controlados | 401 AUTENTICACION_REQUERIDA; 403 ACCESO_DENEGADO. |
| Estado de implementación | Implementado; no certifica seguridad productiva |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/config/SecurityConfig.java#L17) |

### AdminServicioController

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | AdminServicioController |
| Paquete | com.santacecilia.api.controller |
| Responsabilidad | Exponer las rutas REST declaradas y delegar en ServicioService. |
| Métodos principales | `listar(@RequestParam(defaultValue = "0") int pagina, @RequestParam(defaultValue = "25") int tamano)` (L14); `crear(@Valid @RequestBody Guardar body, @AuthenticationPrincipal AuthPrincipal actor)` (L15); `editar(@PathVariable long id, @Valid @RequestBody Guardar body, @AuthenticationPrincipal AuthPrincipal actor)` (L16); `publicar(@PathVariable long id, @Valid @RequestBody Publicacion body, @AuthenticationPrincipal AuthPrincipal actor)` (L17); `retirar(@PathVariable long id, @Valid @RequestBody CambioConMotivo body, @AuthenticationPrincipal AuthPrincipal actor)` (L18) |
| Endpoints relacionados | `GET /api/v1/admin/servicios`; `POST /api/v1/admin/servicios`; `PUT /api/v1/admin/servicios/{id}`; `POST /api/v1/admin/servicios/{id}/publicacion`; `DELETE /api/v1/admin/servicios/{id}` |
| Entidades o registros utilizados | ServicioMusical, Usuario; listas y repertorio mediante ContenidoServicioRepository. |
| Validaciones | @Valid en RequestBody cuando está declarado; parámetros de consulta y actor de @AuthenticationPrincipal. |
| Reglas de negocio | Los permisos y transiciones concretos figuran en el catálogo de endpoints y los Services delegados. |
| Errores controlados | Propaga ApiException y errores de validación al manejo global; SecurityConfig controla 401/403. |
| Estado de implementación | Controller implementado; no acredita validación productiva |
| Evidencia disponible | [informe de interfaz y CRUD](docs/interfaz.md); sin reporte de prueba unitaria backend específico; [fuente original](backend/src/main/java/com/santacecilia/api/controller/AdminServicioController.java#L10) |

### AdminUsuarioController

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | AdminUsuarioController |
| Paquete | com.santacecilia.api.controller |
| Responsabilidad | Exponer las rutas REST declaradas y delegar en UsuarioService. |
| Métodos principales | `listar(@RequestParam(defaultValue = "0") int pagina, @RequestParam(defaultValue = "25") int tamano)` (L14); `obtener(@PathVariable long id)` (L15); `crear(@Valid @RequestBody CrearMusico body, @AuthenticationPrincipal AuthPrincipal actor)` (L16); `editar(@PathVariable long id, @Valid @RequestBody Perfil body, @AuthenticationPrincipal AuthPrincipal actor)` (L17); `estado(@PathVariable long id, @Valid @RequestBody Estado body, @AuthenticationPrincipal AuthPrincipal actor)` (L18); `desactivar(@PathVariable long id, @Valid @RequestBody CambioConMotivo body, @AuthenticationPrincipal AuthPrincipal actor)` (L19) |
| Endpoints relacionados | `GET /api/v1/admin/usuarios`; `GET /api/v1/admin/usuarios/{id}`; `POST /api/v1/admin/usuarios`; `PUT /api/v1/admin/usuarios/{id}`; `PATCH /api/v1/admin/usuarios/{id}/estado`; `DELETE /api/v1/admin/usuarios/{id}` |
| Entidades o registros utilizados | Usuario, FamiliaSesion; historial_operacion por AuditoriaService. |
| Validaciones | @Valid en RequestBody cuando está declarado; parámetros de consulta y actor de @AuthenticationPrincipal. |
| Reglas de negocio | Los permisos y transiciones concretos figuran en el catálogo de endpoints y los Services delegados. |
| Errores controlados | Propaga ApiException y errores de validación al manejo global; SecurityConfig controla 401/403. |
| Estado de implementación | Controller implementado; no acredita validación productiva |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/controller/AdminUsuarioController.java#L10) |

### AuthController

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | AuthController |
| Paquete | com.santacecilia.api.controller |
| Responsabilidad | Exponer las rutas REST declaradas y delegar en AuthService, RecoveryService. |
| Métodos principales | `register(@Valid @RequestBody Registro body, HttpServletRequest request)` (L17); `login(@Valid @RequestBody Login body, HttpServletRequest request)` (L19); `refresh(@Valid @RequestBody Refresh body, HttpServletRequest request)` (L20); `logout(@AuthenticationPrincipal AuthPrincipal actor)` (L21); `forgot(@Valid @RequestBody Forgot body, HttpServletRequest request)` (L23); `reset(@Valid @RequestBody Reset body, HttpServletRequest request)` (L25) |
| Endpoints relacionados | `POST /api/v1/auth/register`; `POST /api/v1/auth/login`; `POST /api/v1/auth/refresh`; `POST /api/v1/auth/logout`; `POST /api/v1/auth/forgot-password`; `POST /api/v1/auth/reset-password` |
| Entidades o registros utilizados | Usuario, Sesion, FamiliaSesion, TokenAcceso; tablas usuario, sesion, auth_familia, token_acceso.; Usuario, RecuperacionAcceso, FamiliaSesion. |
| Validaciones | @Valid en RequestBody cuando está declarado; parámetros de consulta y actor de @AuthenticationPrincipal. |
| Reglas de negocio | Los permisos y transiciones concretos figuran en el catálogo de endpoints y los Services delegados. |
| Errores controlados | Propaga ApiException y errores de validación al manejo global; SecurityConfig controla 401/403. |
| Estado de implementación | Controller implementado; no acredita validación productiva |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/controller/AuthController.java#L12) |

### ContratacionController

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ContratacionController |
| Paquete | com.santacecilia.api.controller |
| Responsabilidad | Exponer las rutas REST declaradas y delegar en ContratacionService. |
| Métodos principales | `solicitar(@Valid @RequestBody Solicitar b, @AuthenticationPrincipal AuthPrincipal a)` (L29); `solicitudes(@RequestParam(defaultValue = "0") int pagina, @RequestParam(defaultValue = "20") int tamano, @RequestParam(required = false) String estado, @RequestParam(required = false) String q, @AuthenticationPrincipal AuthPrincipal a)` (L35); `solicitud(@PathVariable long id, @AuthenticationPrincipal AuthPrincipal a)` (L45); `solicitudEstado(@PathVariable long id, @Valid @RequestBody Cambiar b, @AuthenticationPrincipal AuthPrincipal a)` (L51); `cotizar(@PathVariable long id, @Valid @RequestBody Cotizar b, @AuthenticationPrincipal AuthPrincipal a)` (L59); `responder(@PathVariable long id, @PathVariable long quote, @Valid @RequestBody Responder b, @AuthenticationPrincipal AuthPrincipal a)` (L67); `aceptar(@PathVariable long id, @PathVariable long quote, @Valid @RequestBody Aceptar b, @AuthenticationPrincipal AuthPrincipal a)` (L76); `contratos(@RequestParam(defaultValue = "0") int pagina, @RequestParam(defaultValue = "20") int tamano, @RequestParam(required = false) String estado, @RequestParam(required = false) String q, @AuthenticationPrincipal AuthPrincipal a)` (L85); `contrato(@PathVariable long id, @AuthenticationPrincipal AuthPrincipal a)` (L95); `contratoEstado(@PathVariable long id, @Valid @RequestBody Cambiar b, @AuthenticationPrincipal AuthPrincipal a)` (L101); `disponible(@PathVariable long id, @RequestParam LocalDate desde, @RequestParam LocalDate hasta, @AuthenticationPrincipal AuthPrincipal a)` (L109); `agenda(@PathVariable long id, @RequestParam LocalDate desde, @RequestParam LocalDate hasta, @AuthenticationPrincipal AuthPrincipal a)` (L118); `horarios(@PathVariable long id, @Valid @RequestBody Horarios b, @AuthenticationPrincipal AuthPrincipal a)` (L127); `bloquear(@PathVariable long id, @Valid @RequestBody Bloquear b, @AuthenticationPrincipal AuthPrincipal a)` (L135); `desbloquear(@PathVariable long id, @PathVariable long block, @AuthenticationPrincipal AuthPrincipal a)` (L143); `resumen(@AuthenticationPrincipal AuthPrincipal a)` (L151) |
| Endpoints relacionados | `POST /api/v1/solicitudes`; `GET /api/v1/solicitudes`; `GET /api/v1/solicitudes/{id}`; `POST /api/v1/solicitudes/{id}/estado`; `POST /api/v1/solicitudes/{id}/cotizaciones`; `POST /api/v1/solicitudes/{id}/cotizaciones/{quote}/respuesta`; `POST /api/v1/solicitudes/{id}/cotizaciones/{quote}/aceptacion`; `GET /api/v1/contratos`; `GET /api/v1/contratos/{id}`; `POST /api/v1/contratos/{id}/estado`; `GET /api/v1/servicios/{id}/disponibilidad`; `GET /api/v1/servicios/{id}/agenda`; `PUT /api/v1/servicios/{id}/horarios`; `POST /api/v1/servicios/{id}/bloqueos`; `DELETE /api/v1/servicios/{id}/bloqueos/{block}`; `GET /api/v1/mi-resumen` |
| Entidades o registros utilizados | Registros SQL de solicitud_cotizacion, cotizacion, detalle_cotizacion, contrato, servicio_musical, usuario, integrante, horario_atencion, bloqueo_agenda, reserva, retencion_agenda, ocupacion_agenda, historial_operacion y notificacion. No hay clases JPA Contrato/Cotizacion. |
| Validaciones | @Valid en RequestBody cuando está declarado; parámetros de consulta y actor de @AuthenticationPrincipal. |
| Reglas de negocio | Los permisos y transiciones concretos figuran en el catálogo de endpoints y los Services delegados. |
| Errores controlados | Propaga ApiException y errores de validación al manejo global; SecurityConfig controla 401/403. |
| Estado de implementación | Controller implementado; no acredita validación productiva |
| Evidencia disponible | [15 comprobaciones enumeradas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/contratacion_comprobaciones.json); [registro de 11 de concurrencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/contratacion_concurrencia.json); [informe histórico](docs/contratacion_agenda.md); [fuente original](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L16) |

### EstadoController

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | EstadoController |
| Paquete | com.santacecilia.api.controller |
| Responsabilidad | Exponer las rutas REST declaradas y delegar en JdbcTemplate. |
| Métodos principales | `estado()` (L10) |
| Endpoints relacionados | `GET /api/v1/health` |
| Entidades o registros utilizados | JdbcTemplate: SELECT 1; sin entidad de negocio. |
| Validaciones | @Valid en RequestBody cuando está declarado; parámetros de consulta y actor de @AuthenticationPrincipal. |
| Reglas de negocio | Los permisos y transiciones concretos figuran en el catálogo de endpoints y los Services delegados. |
| Errores controlados | Propaga ApiException y errores de validación al manejo global; SecurityConfig controla 401/403. |
| Estado de implementación | Controller implementado; no acredita validación productiva |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/controller/EstadoController.java#L6) |

### PagoDirectoController

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | PagoDirectoController |
| Paquete | com.santacecilia.api.controller |
| Responsabilidad | Exponer las rutas REST declaradas y delegar en PagoDirectoService. |
| Métodos principales | `cuentas(@AuthenticationPrincipal AuthPrincipal a)` (L26); `cuenta(@Valid @RequestBody Cuenta b, @AuthenticationPrincipal AuthPrincipal a)` (L31); `cuenta(@PathVariable long id, @Valid @RequestBody Cuenta b, @AuthenticationPrincipal AuthPrincipal a)` (L37); `contrato(@PathVariable long id, @AuthenticationPrincipal AuthPrincipal a)` (L45); `iniciar(@PathVariable long id, @Valid @RequestBody Iniciar b, @AuthenticationPrincipal AuthPrincipal a)` (L51); `listar(@RequestParam(defaultValue = "0") int pagina, @RequestParam(required = false) String estado, @AuthenticationPrincipal AuthPrincipal a)` (L59); `pago(@PathVariable long id, @AuthenticationPrincipal AuthPrincipal a)` (L67); `reportar(@PathVariable long id, @Valid @RequestBody Comprobante b, @AuthenticationPrincipal AuthPrincipal a)` (L72); `cancelar(@PathVariable long id, @Valid @RequestBody Cancelar b, @AuthenticationPrincipal AuthPrincipal a)` (L80); `imagen(@PathVariable long id, @AuthenticationPrincipal AuthPrincipal a)` (L88); `revision(@PathVariable long id, @Valid @RequestBody Revision b, @AuthenticationPrincipal AuthPrincipal a)` (L93); `devolver(@PathVariable long id, @Valid @RequestBody Devolver b, @AuthenticationPrincipal AuthPrincipal a)` (L101); `confirmar(@PathVariable long id, @Valid @RequestBody ConfirmarDevolucion b, @AuthenticationPrincipal AuthPrincipal a)` (L109); `imagenDevolucion(@PathVariable long id, @AuthenticationPrincipal AuthPrincipal a)` (L117); `reembolso(@PathVariable long id, @AuthenticationPrincipal AuthPrincipal a)` (L123); `rechazo(@PathVariable long id, @Valid @RequestBody Revision b, @AuthenticationPrincipal AuthPrincipal a)` (L129) |
| Endpoints relacionados | `GET /api/v1/admin/cuentas-cobro`; `POST /api/v1/admin/cuentas-cobro`; `PUT /api/v1/admin/cuentas-cobro/{id}`; `GET /api/v1/contratos/{id}/pagos`; `POST /api/v1/contratos/{id}/pagos`; `GET /api/v1/pagos`; `GET /api/v1/pagos/{id}`; `PUT /api/v1/pagos/{id}/comprobante`; `POST /api/v1/pagos/{id}/cancelacion`; `GET /api/v1/pagos/{id}/comprobante`; `POST /api/v1/admin/pagos/{id}/revision`; `POST /api/v1/admin/pagos/{id}/reembolsos`; `POST /api/v1/admin/reembolsos/{id}/confirmacion`; `GET /api/v1/reembolsos/{id}/comprobante`; `GET /api/v1/reembolsos/{id}`; `POST /api/v1/admin/reembolsos/{id}/rechazo` |
| Entidades o registros utilizados | Registros SQL de pago, pago_directo, contrato, cuenta_cobro, comprobante_directo, movimiento_cuenta, reembolso, incidencia_pago, reserva, ocupacion_agenda, solicitud_cotizacion, historial_operacion, evento_outbox y v_saldo_contrato. No hay clase JPA Pago. |
| Validaciones | @Valid en RequestBody cuando está declarado; parámetros de consulta y actor de @AuthenticationPrincipal. |
| Reglas de negocio | Los permisos y transiciones concretos figuran en el catálogo de endpoints y los Services delegados. |
| Errores controlados | Propaga ApiException y errores de validación al manejo global; SecurityConfig controla 401/403. |
| Estado de implementación | Controller implementado; no acredita validación productiva |
| Evidencia disponible | [28 comprobaciones agrupadas, sintéticas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/pagos_comprobaciones_sinteticas.json); [informe](docs/pagos_arquitectura.md); [fuente original](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L13) |

### ServicioController

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ServicioController |
| Paquete | com.santacecilia.api.controller |
| Responsabilidad | Exponer las rutas REST declaradas y delegar en ServicioService. |
| Métodos principales | `catalogo(@RequestParam(required = false) String q, @RequestParam(required = false) String tipo, @RequestParam(required = false) String genero, @RequestParam(required = false) String ciudad, @RequestParam(required = false) Long tarifaMaxCentimos, @RequestParam java.util.Map<String, String> filtros)` (L15); `detalle(@PathVariable long id, @AuthenticationPrincipal AuthPrincipal actor)` (L19); `propios(@AuthenticationPrincipal AuthPrincipal actor)` (L20); `tarifa(@PathVariable long id, @Valid @RequestBody Tarifa body, @AuthenticationPrincipal AuthPrincipal actor)` (L21); `agregar(@PathVariable long id, @Valid @RequestBody Cancion body, @AuthenticationPrincipal AuthPrincipal actor)` (L22); `editar(@PathVariable long id, @PathVariable long cancion, @Valid @RequestBody Cancion body, @AuthenticationPrincipal AuthPrincipal actor)` (L24); `retirar(@PathVariable long id, @PathVariable long cancion, @AuthenticationPrincipal AuthPrincipal actor)` (L26) |
| Endpoints relacionados | `GET /api/v1/servicios`; `GET /api/v1/servicios/{id}`; `GET /api/v1/mis-servicios`; `PATCH /api/v1/servicios/{id}/tarifa`; `POST /api/v1/servicios/{id}/repertorio`; `PUT /api/v1/servicios/{id}/repertorio/{cancion}`; `DELETE /api/v1/servicios/{id}/repertorio/{cancion}` |
| Entidades o registros utilizados | ServicioMusical, Usuario; listas y repertorio mediante ContenidoServicioRepository. |
| Validaciones | @Valid en RequestBody cuando está declarado; parámetros de consulta y actor de @AuthenticationPrincipal. |
| Reglas de negocio | Los permisos y transiciones concretos figuran en el catálogo de endpoints y los Services delegados. |
| Errores controlados | Propaga ApiException y errores de validación al manejo global; SecurityConfig controla 401/403. |
| Estado de implementación | Controller implementado; no acredita validación productiva |
| Evidencia disponible | [informe de interfaz y CRUD](docs/interfaz.md); sin reporte de prueba unitaria backend específico; [fuente original](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L11) |

### UsuarioController

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | UsuarioController |
| Paquete | com.santacecilia.api.controller |
| Responsabilidad | Exponer las rutas REST declaradas y delegar en UsuarioService. |
| Métodos principales | `me(@AuthenticationPrincipal AuthPrincipal actor)` (L13); `perfil(@Valid @RequestBody Perfil body, @AuthenticationPrincipal AuthPrincipal actor)` (L14) |
| Endpoints relacionados | `GET /api/v1/me`; `PATCH /api/v1/me` |
| Entidades o registros utilizados | Usuario, FamiliaSesion; historial_operacion por AuditoriaService. |
| Validaciones | @Valid en RequestBody cuando está declarado; parámetros de consulta y actor de @AuthenticationPrincipal. |
| Reglas de negocio | Los permisos y transiciones concretos figuran en el catálogo de endpoints y los Services delegados. |
| Errores controlados | Propaga ApiException y errores de validación al manejo global; SecurityConfig controla 401/403. |
| Estado de implementación | Controller implementado; no acredita validación productiva |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/controller/UsuarioController.java#L9) |

### ApiResponse

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ApiResponse |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/dto/ApiResponse.java#L2) |

### AuthDtos

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | AuthDtos |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L4) |

### CambioConMotivo

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | CambioConMotivo |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/dto/CambioConMotivo.java#L3) |

### ContratacionDtos

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ContratacionDtos |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L9) |

### Pagina

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | Pagina |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/dto/Pagina.java#L3) |

### PagoDirectoDtos

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | PagoDirectoDtos |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | [28 comprobaciones agrupadas, sintéticas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/pagos_comprobaciones_sinteticas.json); [informe](docs/pagos_arquitectura.md); [fuente original](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L7) |

### ServicioDtos

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ServicioDtos |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L4) |

### UsuarioDtos

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | UsuarioDtos |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/dto/UsuarioDtos.java#L5) |

### UsuarioResponse

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | UsuarioResponse |
| Paquete | com.santacecilia.api.dto |
| Responsabilidad | Definir entradas o salidas de la API sin exponer entidades completas. |
| Métodos principales | `of(Usuario u)` (L4) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Tipos de datos descritos en sus campos; sin persistencia propia. |
| Validaciones | Consultar la tabla de DTOs con las anotaciones reales de cada componente. |
| Reglas de negocio | Record o contenedor de records; los cálculos y cambios de estado pertenecen a los Services. |
| Errores controlados | 400 VALIDACION/DATOS_INVALIDOS para entradas inválidas; los DTOs de salida no crean errores por sí solos. |
| Estado de implementación | Contrato de datos implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/dto/UsuarioResponse.java#L3) |

### FamiliaSesion

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | FamiliaSesion |
| Paquete | com.santacecilia.api.entity |
| Responsabilidad | Representar auth_familia en el modelo Java. |
| Métodos principales | `getId()` (L10); `getUsuarioId()` (L11); `getRevocadaEn()` (L13) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | auth_familia |
| Validaciones | Anotaciones de persistencia; no equivale a un DTO @Valid. |
| Reglas de negocio | Mapeo JPA de columnas y claves; reglas de negocio en Services. |
| Errores controlados | Excepciones JPA se traducen por Services/GlobalExceptionHandler; Rol.fromId puede fallar si el código es desconocido. |
| Estado de implementación | Entidad o enum implementado; no se incluyen registros de personas |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/entity/FamiliaSesion.java#L4) |

### RecuperacionAcceso

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | RecuperacionAcceso |
| Paquete | com.santacecilia.api.entity |
| Responsabilidad | Representar recuperacion_acceso en el modelo Java. |
| Métodos principales | `getId()` (L12); `getUsuarioId()` (L13); `getTokenHash()` (L15); `getVenceEn()` (L19) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | recuperacion_acceso |
| Validaciones | Anotaciones de persistencia; no equivale a un DTO @Valid. |
| Reglas de negocio | Mapeo JPA de columnas y claves; reglas de negocio en Services. |
| Errores controlados | Excepciones JPA se traducen por Services/GlobalExceptionHandler; Rol.fromId puede fallar si el código es desconocido. |
| Estado de implementación | Entidad o enum implementado; no se incluyen registros de personas |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/entity/RecuperacionAcceso.java#L4) |

### Rol

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | Rol |
| Paquete | com.santacecilia.api.entity |
| Responsabilidad | Representar los cuatro roles mediante un enum Java. |
| Métodos principales | `getId()` (L6); `fromId(short id)` (L7) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Códigos de la tabla rol y campo Usuario.rolId. |
| Validaciones | fromId exige un código declarado. |
| Reglas de negocio | ADMINISTRADOR(1), CLIENTE(2), DIRECTOR(3) y SOLISTA(4); no es una entidad JPA. |
| Errores controlados | IllegalStateException si el código de base de datos no corresponde a un rol. |
| Estado de implementación | Enum implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/entity/Rol.java#L2) |

### ServicioMusical

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ServicioMusical |
| Paquete | com.santacecilia.api.entity |
| Responsabilidad | Representar servicio_musical en el modelo Java. |
| Métodos principales | `getId()` (L20); `getVersion()` (L21); `getEstadoPublicacion()` (L38) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | servicio_musical |
| Validaciones | Anotaciones de persistencia; no equivale a un DTO @Valid. |
| Reglas de negocio | Mapeo JPA de columnas y claves; control @Version. |
| Errores controlados | Excepciones JPA se traducen por Services/GlobalExceptionHandler; Rol.fromId puede fallar si el código es desconocido. |
| Estado de implementación | Entidad o enum implementado; no se incluyen registros de personas |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/entity/ServicioMusical.java#L4) |

### Sesion

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | Sesion |
| Paquete | com.santacecilia.api.entity |
| Responsabilidad | Representar sesion en el modelo Java. |
| Métodos principales | `getId()` (L14); `getUsuarioId()` (L15); `getFamilia()` (L17); `getRefreshHash()` (L19); `getVenceEn()` (L23); `getConsumidaEn()` (L25); `getRevocadaEn()` (L27) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | sesion |
| Validaciones | Anotaciones de persistencia; no equivale a un DTO @Valid. |
| Reglas de negocio | Mapeo JPA de columnas y claves; reglas de negocio en Services. |
| Errores controlados | Excepciones JPA se traducen por Services/GlobalExceptionHandler; Rol.fromId puede fallar si el código es desconocido. |
| Estado de implementación | Entidad o enum implementado; no se incluyen registros de personas |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/entity/Sesion.java#L4) |

### TokenAcceso

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | TokenAcceso |
| Paquete | com.santacecilia.api.entity |
| Responsabilidad | Representar token_acceso en el modelo Java. |
| Métodos principales | `getId()` (L11); `getSesionId()` (L12); `getTokenHash()` (L14); `getVenceEn()` (L18) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | token_acceso |
| Validaciones | Anotaciones de persistencia; no equivale a un DTO @Valid. |
| Reglas de negocio | Mapeo JPA de columnas y claves; reglas de negocio en Services. |
| Errores controlados | Excepciones JPA se traducen por Services/GlobalExceptionHandler; Rol.fromId puede fallar si el código es desconocido. |
| Estado de implementación | Entidad o enum implementado; no se incluyen registros de personas |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/entity/TokenAcceso.java#L4) |

### Usuario

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | Usuario |
| Paquete | com.santacecilia.api.entity |
| Responsabilidad | Representar usuario en el modelo Java. |
| Métodos principales | `getId()` (L22); `getVersion()` (L23); `getRolId()` (L24); `getEstado()` (L42) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | usuario |
| Validaciones | Anotaciones de persistencia; no equivale a un DTO @Valid. |
| Reglas de negocio | Mapeo JPA de columnas y claves; control @Version. |
| Errores controlados | Excepciones JPA se traducen por Services/GlobalExceptionHandler; Rol.fromId puede fallar si el código es desconocido. |
| Estado de implementación | Entidad o enum implementado; no se incluyen registros de personas |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/entity/Usuario.java#L4) |

### ApiError

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ApiError |
| Paquete | com.santacecilia.api.exception |
| Responsabilidad | Definir el contrato JSON de error. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | Map<String,String> para errores de campo. |
| Validaciones | Estructura de salida; no validación de negocio. |
| Reglas de negocio | Record de code, message, fieldErrors y correlationId. |
| Errores controlados | Transporta los estados decididos por filtros/handlers. |
| Estado de implementación | Record implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/exception/ApiError.java#L3) |

### ApiException

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ApiException |
| Paquete | com.santacecilia.api.exception |
| Responsabilidad | Representar errores de negocio con estado y código. |
| Métodos principales | `getStatus()` (L7); `getCode()` (L7); `notFound()` (L8); `conflict(String message)` (L9); `invalid(String message)` (L10); `unauthenticated()` (L11) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | HttpStatus. |
| Validaciones | No valida entradas directamente. |
| Reglas de negocio | Factories notFound, conflict, invalid y unauthenticated; estado explícito. |
| Errores controlados | 400 DATOS_INVALIDOS; 401 CREDENCIALES_INVALIDAS; 404 NO_ENCONTRADO; 409 CONFLICTO, más estados explícitos por constructor. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/exception/ApiException.java#L3) |

### GlobalExceptionHandler

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | GlobalExceptionHandler |
| Paquete | com.santacecilia.api.exception |
| Responsabilidad | Traducir excepciones a respuestas HTTP seguras. |
| Métodos principales | `api(ApiException e, HttpServletRequest r)` (L19); `validation(MethodArgumentNotValidException e, HttpServletRequest r)` (L20); `invalid(Exception e, HttpServletRequest r)` (L24); `integrity(Exception e, HttpServletRequest r)` (L26); `stale(Exception e, HttpServletRequest r)` (L27); `denied(Exception e, HttpServletRequest r)` (L28); `missing(Exception e, HttpServletRequest r)` (L29); `method(Exception e, HttpServletRequest r)` (L31); `unexpected(Exception e, HttpServletRequest r)` (L33) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | ApiError y ResponseEntity. |
| Validaciones | Bean Validation, formato JSON/parámetros, integridad y versión. |
| Reglas de negocio | No publica SQL ni trazas; registra solo correlación y tipo de error inesperado. |
| Errores controlados | 400, 403, 404, 405, 409 y 500; ApiException conserva su estado. |
| Estado de implementación | Implementado; filtros pueden responder fuera de este contrato |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/exception/GlobalExceptionHandler.java#L13) |

### TokenRejectedException

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | TokenRejectedException |
| Paquete | com.santacecilia.api.exception |
| Responsabilidad | Representar rechazo de sesión que no revierte la revocación de familia. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | Extiende ApiException. |
| Validaciones | Formato/consumo/vigencia se verifican en AuthService. |
| Reglas de negocio | AuthService.refresh declara noRollbackFor para conservar una revocación cuando responde 401. |
| Errores controlados | 401 SESION_INVALIDA. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/exception/TokenRejectedException.java#L4) |

### ContenidoServicioRepository

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ContenidoServicioRepository |
| Paquete | com.santacecilia.api.repository |
| Responsabilidad | Persistir listas normalizadas y repertorio de servicios. |
| Métodos principales | `generos(long id)` (L10); `instrumentos(long id)` (L11); `tiposEvento(long id)` (L12); `reemplazarListas(long id, Guardar input)` (L13); `repertorio(long id)` (L21); `agregarCancion(long id, Cancion input)` (L25); `editarCancion(long servicio, long cancion, Cancion input)` (L32); `retirarCancion(long servicio, long cancion)` (L33); `tieneHistoria(long servicio)` (L34); `crearRecursoServicio(long servicio)` (L35); `asegurarRecursoMusico(long usuario)` (L36) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | servicio_genero, servicio_instrumento, servicio_tipo_evento, repertorio, solicitud_cotizacion, bloqueo_agenda y recurso_agenda. |
| Validaciones | SQL con parámetros; autorización y transacción en ServicioService; deduplicación de listas. |
| Reglas de negocio | Reemplazo de listas, alta/edición/retiro lógico de canciones; comprobación de historia y alta de recursos. |
| Errores controlados | Propaga errores JDBC; edición/retiro devuelven false si no se afecta la fila. |
| Estado de implementación | Implementado para contenido descrito |
| Evidencia disponible | [informe de interfaz y CRUD](docs/interfaz.md); sin reporte de prueba unitaria backend específico; [fuente original](backend/src/main/java/com/santacecilia/api/repository/ContenidoServicioRepository.java#L6) |

### ContratacionRepository

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ContratacionRepository |
| Paquete | com.santacecilia.api.repository |
| Responsabilidad | Acceso JDBC parametrizado y protocolo de recursos compartidos. |
| Métodos principales | `rows(String sql, Object... args)` (L21); `one(String sql, Object... args)` (L25); `update(String sql, Object... args)` (L31); `insert(String sql, Object... args)` (L35); `number(Map<String, Object> row, String key)` (L40); `instant(Object value)` (L44); `utc(Instant value)` (L49); `recursos(long servicio)` (L53); `lock(List<Long> resources)` (L80); `libre(List<Long> resources, Instant inicio, Instant fin)` (L86); `salida(Map<String, Object> source)` (L101) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Map<String,Object> de tablas centrales y recurso_agenda/ocupacion_agenda; no repositorios JPA de Contrato o Pago. |
| Validaciones | Conjunto de recursos completo y no vacío; conversión de fechas UTC; un recurso con cruce impide la operación. |
| Reglas de negocio | Resolver servicio, responsable e integrantes vinculados ACEPTADO; exigir recursos completos; bloquear IDs en TreeSet; comprobar intervalos semiabiertos con lectura actual FOR UPDATE. |
| Errores controlados | 404 one sin fila; 409 recursos incompletos o superposición; excepciones de Spring JDBC. |
| Estado de implementación | Implementado; garantía depende de transacción del Service |
| Evidencia disponible | [15 comprobaciones enumeradas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/contratacion_comprobaciones.json); [registro de 11 de concurrencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/contratacion_concurrencia.json); [informe histórico](docs/contratacion_agenda.md); [fuente original](backend/src/main/java/com/santacecilia/api/repository/ContratacionRepository.java#L13) |

### FamiliaSesionRepository

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | FamiliaSesionRepository |
| Paquete | com.santacecilia.api.repository |
| Responsabilidad | Bloquear familias y revocar sesiones de un usuario. |
| Métodos principales | `bloquear(String id)` (L8); `revocarUsuario(long usuarioId, LocalDateTime ahora)` (L10) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | FamiliaSesion; tabla auth_familia. |
| Validaciones | Se ejecuta bajo transacción del llamador. |
| Reglas de negocio | PESSIMISTIC_WRITE por familia y actualización masiva solo de familias no revocadas. |
| Errores controlados | Optional vacío/excepciones JPA. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/repository/FamiliaSesionRepository.java#L7) |

### RecuperacionRepository

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | RecuperacionRepository |
| Paquete | com.santacecilia.api.repository |
| Responsabilidad | Buscar enlaces de recuperación por hash e invalidarlos. |
| Métodos principales | `findByTokenHash(byte[] tokenHash)` (L7); `invalidarUsuario(long usuarioId, LocalDateTime ahora)` (L8) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | RecuperacionAcceso; tabla recuperacion_acceso. |
| Validaciones | Transacción y bloqueo de usuario en el Service. |
| Reglas de negocio | Invalida enlaces sin uso de un usuario; consumo y vigencia se resuelven en RecoveryService. |
| Errores controlados | Optional vacío/excepciones JPA. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/repository/RecuperacionRepository.java#L6) |

### ServicioRepository

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ServicioRepository |
| Paquete | com.santacecilia.api.repository |
| Responsabilidad | Consultar servicios propios, publicados y filas para actualización. |
| Métodos principales | `findByResponsableIdOrderByNombreAsc(long responsableId)` (L8); `publicados()` (L9); `bloquear(long id)` (L11) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | ServicioMusical; consulta conjunta con Usuario. |
| Validaciones | Propiedad y estados adicionales en ServicioService. |
| Reglas de negocio | Solo PUBLICADO con usuario ACTIVO en publicados; bloqueo PESSIMISTIC_WRITE por id. |
| Errores controlados | Optional vacío/excepciones JPA. |
| Estado de implementación | Implementado |
| Evidencia disponible | [informe de interfaz y CRUD](docs/interfaz.md); sin reporte de prueba unitaria backend específico; [fuente original](backend/src/main/java/com/santacecilia/api/repository/ServicioRepository.java#L7) |

### SesionRepository

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | SesionRepository |
| Paquete | com.santacecilia.api.repository |
| Responsabilidad | Buscar la sesión por hash del refresh. |
| Métodos principales | `findByRefreshHash(byte[] refreshHash)` (L6) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Sesion; JpaRepository<Sesion,Long>. |
| Validaciones | Validez, revocación y consumo en AuthService. |
| Reglas de negocio | Conserva sesión y familia; no devuelve tokens en claro desde la base. |
| Errores controlados | Optional vacío/excepciones JPA. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/repository/SesionRepository.java#L5) |

### TokenAccesoRepository

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | TokenAccesoRepository |
| Paquete | com.santacecilia.api.repository |
| Responsabilidad | Buscar un token de acceso por su hash. |
| Métodos principales | `findByTokenHash(byte[] tokenHash)` (L6) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | TokenAcceso; JpaRepository<TokenAcceso,Long>. |
| Validaciones | La autenticación completa consulta sesión, familia y usuario. |
| Reglas de negocio | El token en claro no se guarda como valor de una fila. |
| Errores controlados | Optional vacío/excepciones JPA. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/repository/TokenAccesoRepository.java#L5) |

### UsuarioRepository

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | UsuarioRepository |
| Paquete | com.santacecilia.api.repository |
| Responsabilidad | Consultar usuarios y bloquear identidad para escrituras. |
| Métodos principales | `findByCorreoNormalizado(String correo)` (L7); `existsByRolId(short rolId)` (L9); `bloquear(long id)` (L10); `bloquearCorreo(String correo)` (L12) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | Usuario; JpaRepository<Usuario,Long>. |
| Validaciones | Métodos tipados y parámetros JPA; reglas de rol y versión en Services. |
| Reglas de negocio | Normaliza correo con lower/trim; PESSIMISTIC_WRITE en bloquear y bloquearCorreo. |
| Errores controlados | Optional vacío o excepciones JPA; traducidos por el llamador. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/repository/UsuarioRepository.java#L6) |

### AuthPrincipal

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | AuthPrincipal |
| Paquete | com.santacecilia.api.security |
| Responsabilidad | Transportar identidad autorizada dentro del servidor. |
| Métodos principales | Sin métodos explícitos de negocio; consultar componentes o records anidados. |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | Rol. |
| Validaciones | Se construye tras autenticar con base de datos. |
| Reglas de negocio | Record con usuarioId, rol y familia; no representa un JWT ni un selector de rol de Android. |
| Errores controlados | No controla HTTP por sí mismo. |
| Estado de implementación | Record implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/security/AuthPrincipal.java#L3) |

### BearerAuthenticationFilter

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | BearerAuthenticationFilter |
| Paquete | com.santacecilia.api.security |
| Responsabilidad | Resolver Authorization Bearer a una identidad autenticada. |
| Métodos principales | `doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)` (L16) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | AuthPrincipal, AuthService y ApiError. |
| Validaciones | Prefijo Bearer y validación de sesión persistida. |
| Reglas de negocio | Llama AuthService.autenticar y crea autoridades ROLE_ a partir del rol oficial; un header inválido se rechaza incluso en ruta pública. |
| Errores controlados | 401 SESION_INVALIDA. |
| Estado de implementación | Implementado |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/security/BearerAuthenticationFilter.java#L13) |

### RequestThrottle

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | RequestThrottle |
| Paquete | com.santacecilia.api.security |
| Responsabilidad | Limitar intentos de acceso en la instancia local. |
| Métodos principales | `check(String key, int max, Duration duration)` (L14) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | Record interno Window. |
| Validaciones | Caducidad por Clock; máximo 10000 claves residentes. |
| Reglas de negocio | Ventanas por IP/cuenta y mapa acotado; límites definidos por AuthController/AuthService. |
| Errores controlados | 429 DEMASIADOS_INTENTOS. |
| Estado de implementación | Implementado por instancia; coordinación distribuida pendiente |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/security/RequestThrottle.java#L8) |

### StrongPassword

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | StrongPassword |
| Paquete | com.santacecilia.api.security |
| Responsabilidad | Declarar la validación de contraseña del dominio. |
| Métodos principales | `message()` (L8); `groups()` (L9); `payload()` (L10) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | StrongPasswordValidator. |
| Validaciones | Restricción de campo/entrada; no contiene una contraseña. |
| Reglas de negocio | Anotación Bean Validation enlazada a StrongPasswordValidator. |
| Errores controlados | Errores 400 VALIDACION al fallar un DTO validado. |
| Estado de implementación | Anotación implementada |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/security/StrongPassword.java#L4) |

### StrongPasswordValidator

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | StrongPasswordValidator |
| Paquete | com.santacecilia.api.security |
| Responsabilidad | Verificar longitud y caracteres de la contraseña recibida. |
| Métodos principales | `isValid(String value, ConstraintValidatorContext context)` (L5) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | ConstraintValidator<StrongPassword,String>. |
| Validaciones | isValid devuelve boolean; validación aplicada por @StrongPassword. |
| Reglas de negocio | Al menos 12 puntos de código, máximo 72 bytes UTF-8 y sin controles. |
| Errores controlados | 400 por Bean Validation en Controller; no lanza un estado propio. |
| Estado de implementación | Implementado |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/security/StrongPasswordValidator.java#L4) |

### TokenCodec

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | TokenCodec |
| Paquete | com.santacecilia.api.security |
| Responsabilidad | Generar valores opacos y calcular hash de credenciales temporales. |
| Métodos principales | `nuevo(String prefix)` (L9); `hash(String raw)` (L10); `formato(String raw, String prefix)` (L14) |
| Endpoints relacionados | No declara endpoints propios. Actúa transversalmente sobre rutas API. |
| Entidades o registros utilizados | Sin entidad; consumido por autenticación y recuperación. |
| Validaciones | Formato de prefijo y 43 caracteres Base64 URL. |
| Reglas de negocio | SecureRandom de 32 bytes, Base64 URL y SHA-256; prefijos a1/r1/p1 definidos por el llamador. |
| Errores controlados | IllegalStateException si SHA-256 no está disponible; no estado HTTP propio. |
| Estado de implementación | Implementado; no se incluyen valores de ejecución |
| Evidencia disponible | Fuente incluida e inspección estática; [lint Android (no prueba de esta clase backend)](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt); no se atribuye una prueba específica no documentada; [fuente original](backend/src/main/java/com/santacecilia/api/security/TokenCodec.java#L6) |

### AuthService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | AuthService |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Registrar clientes y administrar sesiones opacas. |
| Métodos principales | `registrar(Registro input)` (L43); `login(Login input)` (L52); `emitir(Usuario u, String familia, LocalDateTime limiteRefresh)` (L64); `refresh(Refresh input)` (L72); `autenticar(String access)` (L87); `logout(AuthPrincipal actor)` (L99) |
| Endpoints relacionados | `POST /api/v1/auth/register`; `POST /api/v1/auth/login`; `POST /api/v1/auth/refresh`; `POST /api/v1/auth/logout` |
| Entidades o registros utilizados | Usuario, Sesion, FamiliaSesion, TokenAcceso; tablas usuario, sesion, auth_familia, token_acceso. |
| Validaciones | Correo único, longitud UTF-8 en login y configuración de TTL; DTO de entrada validado en Controller. |
| Reglas de negocio | Registro fijo CLIENTE; bcrypt; usuario activo; rotación y revocación de familias; verificar token, cuenta y vigencias. |
| Errores controlados | 401 credenciales/sesión; 409 correo duplicado; 429 límite de intentos. |
| Estado de implementación | Implementado localmente |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/service/AuthService.java#L16) |

### ComprobanteImagenService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ComprobanteImagenService |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Validar y recodificar imágenes de comprobantes. |
| Métodos principales | `normalizar(String base64)` (L18) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | BufferedImage y bytes; no entidad JPA. |
| Validaciones | Entrada <=2 MB, lados <=4096 y <=4 millones de píxeles; salida <=1 MB. |
| Reglas de negocio | Solo JPEG/PNG; recodifica a JPEG sin metadatos; semáforo de dos procesamientos concurrentes. |
| Errores controlados | 400 imagen inválida; 429 IMAGEN_EN_PROCESO. |
| Estado de implementación | Implementado localmente |
| Evidencia disponible | [28 comprobaciones agrupadas, sintéticas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/pagos_comprobaciones_sinteticas.json); [informe](docs/pagos_arquitectura.md); [fuente original](backend/src/main/java/com/santacecilia/api/service/ComprobanteImagenService.java#L14) |

### ContratacionService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ContratacionService |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Solicitudes, cotizaciones, contratos y agenda. |
| Métodos principales | `write(Supplier<T> work)` (L51); `propietario(Map<String, Object> s, AuthPrincipal a)` (L90); `version(Map<String, Object> row, Long value)` (L101); `intervalo(Instant inicio, Instant fin)` (L117); `mismaHuella(Object stored, byte[] input)` (L141); `atencion(long servicio, Instant inicio, Instant fin)` (L194); `solicitar(Solicitar b, AuthPrincipal a)` (L245); `listado(String entidad, int pagina, int tamano, String estado, String q, AuthPrincipal a)` (L308); `detalleSolicitud(long id, AuthPrincipal a)` (L363); `cambiarSolicitud(long id, Cambiar b, AuthPrincipal a)` (L411); `cotizar(long id, Cotizar b, AuthPrincipal a)` (L460); `vigente(long quote, long solicitud)` (L554); `responder(long id, long quote, Responder b, AuthPrincipal a)` (L573); `aceptar(long id, long quote, Aceptar b, AuthPrincipal a)` (L609); `detalleContrato(long id, AuthPrincipal a)` (L725); `cambiarContrato(long id, Cambiar b, AuthPrincipal a)` (L742); `agenda(long id, LocalDate desde, LocalDate hasta, AuthPrincipal a, boolean privada)` (L818); `horarios(long id, Horarios b, AuthPrincipal a)` (L879); `bloquear(long id, Bloquear b, AuthPrincipal a)` (L932); `quitarBloqueo(long id, long block, AuthPrincipal a)` (L965); `resumen(AuthPrincipal a)` (L1005) |
| Endpoints relacionados | `POST /api/v1/solicitudes`; `GET /api/v1/solicitudes`; `GET /api/v1/solicitudes/{id}`; `POST /api/v1/solicitudes/{id}/estado`; `POST /api/v1/solicitudes/{id}/cotizaciones`; `POST /api/v1/solicitudes/{id}/cotizaciones/{quote}/respuesta`; `POST /api/v1/solicitudes/{id}/cotizaciones/{quote}/aceptacion`; `GET /api/v1/contratos`; `GET /api/v1/contratos/{id}`; `POST /api/v1/contratos/{id}/estado`; `GET /api/v1/servicios/{id}/disponibilidad`; `GET /api/v1/servicios/{id}/agenda`; `PUT /api/v1/servicios/{id}/horarios`; `POST /api/v1/servicios/{id}/bloqueos`; `DELETE /api/v1/servicios/{id}/bloqueos/{block}`; `GET /api/v1/mi-resumen` |
| Entidades o registros utilizados | Registros SQL de solicitud_cotizacion, cotizacion, detalle_cotizacion, contrato, servicio_musical, usuario, integrante, horario_atencion, bloqueo_agenda, reserva, retencion_agenda, ocupacion_agenda, historial_operacion y notificacion. No hay clases JPA Contrato/Cotizacion. |
| Validaciones | Intervalo futuro de hasta 24 h y precisión de segundos; franjas/márgenes; versión, propietario, vigencia, conceptos y total; clave/huella. |
| Reglas de negocio | Solicitud no reserva; última propuesta vigente y consentimiento crean snapshot y contrato PENDIENTE_PAGO; recursos bloqueados en orden; finalización solo después del evento. |
| Errores controlados | 400 entradas; 404 propiedad/actor; 409 estado, vigencia, superposición, versión o clave reutilizada con otros datos. |
| Estado de implementación | Implementado localmente dentro de esas transiciones |
| Evidencia disponible | [15 comprobaciones enumeradas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/contratacion_comprobaciones.json); [registro de 11 de concurrencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/contratacion_concurrencia.json); [informe histórico](docs/contratacion_agenda.md); [fuente original](backend/src/main/java/com/santacecilia/api/service/ContratacionService.java#L24) |

### PagoAvisosService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | PagoAvisosService |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Entregar outbox de pago a notificaciones internas. |
| Métodos principales | `entregar()` (L28) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | evento_outbox, notificacion, usuario, rol mediante ContratacionRepository. |
| Validaciones | Selecciona solo AVISO_INTERNO/PENDIENTE; destinatarios del contrato y administradores activos cuando corresponde. |
| Reglas de negocio | Tarea cada 5 s, lotes de 20, FOR UPDATE SKIP LOCKED; notificación y estado ENVIADO en una transacción; sin mensajes externos. |
| Errores controlados | No endpoint; fallos revierten la transacción y quedan sujetos al siguiente ciclo del scheduler. |
| Estado de implementación | Procesamiento interno implementado; bandeja visible pendiente |
| Evidencia disponible | [28 comprobaciones agrupadas, sintéticas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/pagos_comprobaciones_sinteticas.json); [informe](docs/pagos_arquitectura.md); [fuente original](backend/src/main/java/com/santacecilia/api/service/PagoAvisosService.java#L17) |

### PagoDirectoService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | PagoDirectoService |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Pagos directos, comprobantes, conciliación y seguimiento de devoluciones. |
| Métodos principales | `write(Supplier<T> work)` (L51); `same(Object stored, byte[] expected)` (L86); `version(Map<String, Object> row, long version)` (L91); `recursos(Map<String, Object> c)` (L119); `bloquearContrato(long id, AuthPrincipal a)` (L125); `cuentas(AuthPrincipal a)` (L222); `guardarCuenta(Long id, Cuenta b, AuthPrincipal a)` (L229); `resumen(long contrato, AuthPrincipal a)` (L293); `iniciar(long id, Iniciar b, AuthPrincipal a)` (L317); `detalle(long id, AuthPrincipal a)` (L403); `listar(int pagina, String estado, AuthPrincipal a)` (L460); `reportar(long id, Comprobante b, AuthPrincipal a)` (L506); `cancelar(long id, Cancelar b, AuthPrincipal a)` (L559); `comprobante(long id, boolean reembolso, AuthPrincipal a)` (L584); `movimiento(long cuenta, Long pago, Long reembolso, String op, LocalDate date, long importe, AuthPrincipal a)` (L602); `incidencia(long id, long c, String tipo, String detalle)` (L624); `revisar(long id, Revision b, AuthPrincipal a)` (L633); `devolver(long id, Devolver b, AuthPrincipal a)` (L785); `confirmarDevolucion(long id, ConfirmarDevolucion b, AuthPrincipal a)` (L853); `detalleReembolso(long id, AuthPrincipal a)` (L965); `rechazarDevolucion(long id, Revision b, AuthPrincipal a)` (L975) |
| Endpoints relacionados | `GET /api/v1/admin/cuentas-cobro`; `POST /api/v1/admin/cuentas-cobro`; `PUT /api/v1/admin/cuentas-cobro/{id}`; `GET /api/v1/contratos/{id}/pagos`; `POST /api/v1/contratos/{id}/pagos`; `GET /api/v1/pagos`; `GET /api/v1/pagos/{id}`; `PUT /api/v1/pagos/{id}/comprobante`; `POST /api/v1/pagos/{id}/cancelacion`; `GET /api/v1/pagos/{id}/comprobante`; `POST /api/v1/admin/pagos/{id}/revision`; `POST /api/v1/admin/pagos/{id}/reembolsos`; `POST /api/v1/admin/reembolsos/{id}/confirmacion`; `GET /api/v1/reembolsos/{id}/comprobante`; `GET /api/v1/reembolsos/{id}`; `POST /api/v1/admin/reembolsos/{id}/rechazo` |
| Entidades o registros utilizados | Registros SQL de pago, pago_directo, contrato, cuenta_cobro, comprobante_directo, movimiento_cuenta, reembolso, incidencia_pago, reserva, ocupacion_agenda, solicitud_cotizacion, historial_operacion, evento_outbox y v_saldo_contrato. No hay clase JPA Pago. |
| Validaciones | Propiedad/rol, estado/versión, cuenta y medio habilitados, saldo, importe, fecha, operación, imagen normalizada y huellas. |
| Reglas de negocio | Solo ADMIN contrasta ingresos; reporte no abona; primer abono aplicable reserva; movimiento único; conflictos conservan ingreso sin aplicación; devolver no mueve dinero. |
| Errores controlados | 400 entradas; 404 actor/recurso; 409 estados, duplicados y saldo; 429 imagen por servicio delegado. Incidencia financiera puede devolver 200 con EN_REVISION, sin aplicar abono. |
| Estado de implementación | Implementado como conciliación humana; sin pasarela automática |
| Evidencia disponible | [28 comprobaciones agrupadas, sintéticas](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/pagos_comprobaciones_sinteticas.json); [informe](docs/pagos_arquitectura.md); [fuente original](backend/src/main/java/com/santacecilia/api/service/PagoDirectoService.java#L28) |

### RecoveryMailSender

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | RecoveryMailSender |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Preparar y enviar correo de recuperación tras el commit. |
| Métodos principales | `disponible()` (L18); `enviar(RecoveryService.Solicitada event)` (L23); `entregar(RecoveryService.Solicitada event)` (L28) |
| Endpoints relacionados | No declara endpoints propios. Se utiliza desde otros componentes; no se atribuye una ruta inexistente. |
| Entidades o registros utilizados | RecoveryService.Solicitada y SimpleMailMessage; sin entidad JPA propia. |
| Validaciones | Proveedor de correo, host, remitente y URL presentes; HTTPS o HTTP de loopback. |
| Reglas de negocio | Escucha RecoveryService.Solicitada en AFTER_COMMIT y usa correoExecutor; no registra el token en logs. |
| Errores controlados | Fallo de envío/cola se registra por tipo; 202 de solicitud no garantiza entrega del correo. |
| Estado de implementación | Implementado; SMTP real no acreditado |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/service/RecoveryMailSender.java#L9) |

### RecoveryService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | RecoveryService |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Solicitar recuperación y restablecer contraseña. |
| Métodos principales | `solicitar(Forgot request)` (L31); `restablecer(Reset request)` (L42) |
| Endpoints relacionados | `POST /api/v1/auth/forgot-password`; `POST /api/v1/auth/reset-password` |
| Entidades o registros utilizados | Usuario, RecuperacionAcceso, FamiliaSesion. |
| Validaciones | SMTP disponible, cuenta activa, formato de token, vigencia y consumo único; nueva contraseña con StrongPassword. |
| Reglas de negocio | Token de un uso; invalida enlaces anteriores; mutex de usuario y revocación de sesiones; evento después de confirmar transacción. |
| Errores controlados | 400 ENLACE_INVALIDO; 503 CORREO_NO_CONFIGURADO. |
| Estado de implementación | Implementado; operación externa condicionada a SMTP |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/service/RecoveryService.java#L15) |

### ServicioService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | ServicioService |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Catálogo, publicación, tarifa y repertorio de servicios. |
| Métodos principales | `catalogo(String q, String tipo, String genero, String ciudad, Long tarifaMax)` (L22); `obtener(long id, AuthPrincipal actor)` (L39); `listar(int pagina, int tamano)` (L45); `propios(AuthPrincipal actor)` (L51); `crear(Guardar input, AuthPrincipal actor)` (L53); `editar(long id, Guardar input, AuthPrincipal actor)` (L61); `publicacion(long id, Publicacion input, AuthPrincipal actor)` (L72); `tarifa(long id, Tarifa input, AuthPrincipal actor)` (L82); `agregarCancion(long id, Cancion input, AuthPrincipal actor)` (L88); `editarCancion(long id, long cancion, Cancion input, AuthPrincipal actor)` (L94); `retirarCancion(long id, long cancion, AuthPrincipal actor)` (L100); `validarResponsable(Guardar input)` (L107); `propietario(ServicioMusical s, AuthPrincipal actor)` (L112); `version(ServicioMusical s, long v)` (L113) |
| Endpoints relacionados | `GET /api/v1/admin/servicios`; `POST /api/v1/admin/servicios`; `PUT /api/v1/admin/servicios/{id}`; `POST /api/v1/admin/servicios/{id}/publicacion`; `DELETE /api/v1/admin/servicios/{id}`; `GET /api/v1/servicios`; `GET /api/v1/servicios/{id}`; `GET /api/v1/mis-servicios`; `PATCH /api/v1/servicios/{id}/tarifa`; `POST /api/v1/servicios/{id}/repertorio`; `PUT /api/v1/servicios/{id}/repertorio/{cancion}`; `DELETE /api/v1/servicios/{id}/repertorio/{cancion}` |
| Entidades o registros utilizados | ServicioMusical, Usuario; listas y repertorio mediante ContenidoServicioRepository. |
| Validaciones | Propiedad/rol, versión, responsable activo, filtros, paginación y repertorio mínimo. |
| Reglas de negocio | Servicio BANDA requiere director; SOLISTA requiere solista activo; tipo inmutable; no reasignar con historia; publicar exige canción; tarifa no reescribe contratos. |
| Errores controlados | 400 filtros/rol; 404 recurso/propiedad; 409 historia, versión o publicación. |
| Estado de implementación | Implementado en catálogo y repertorio; imágenes/integrantes incompletos |
| Evidencia disponible | [informe de interfaz y CRUD](docs/interfaz.md); sin reporte de prueba unitaria backend específico; [fuente original](backend/src/main/java/com/santacecilia/api/service/ServicioService.java#L15) |

### UsuarioService

| Atributo | Información comprobada |
|---|---|
| Nombre de la clase | UsuarioService |
| Paquete | com.santacecilia.api.service |
| Responsabilidad | Gestionar cuentas, perfil y estado administrativo. |
| Métodos principales | `propio(AuthPrincipal actor)` (L23); `listar(int pagina, int tamano)` (L24); `obtener(long id)` (L30); `crearMusico(CrearMusico input, AuthPrincipal actor)` (L32); `editarPropio(Perfil input, AuthPrincipal actor)` (L41); `editarAdmin(long id, Perfil input, AuthPrincipal actor)` (L42); `estado(long id, Estado input, AuthPrincipal actor)` (L50); `version(Usuario u, long version)` (L59) |
| Endpoints relacionados | `GET /api/v1/admin/usuarios`; `GET /api/v1/admin/usuarios/{id}`; `POST /api/v1/admin/usuarios`; `PUT /api/v1/admin/usuarios/{id}`; `PATCH /api/v1/admin/usuarios/{id}/estado`; `DELETE /api/v1/admin/usuarios/{id}`; `GET /api/v1/me`; `PATCH /api/v1/me` |
| Entidades o registros utilizados | Usuario, FamiliaSesion; historial_operacion por AuditoriaService. |
| Validaciones | Rol musical admitido, correo único, paginación 1–100, versión actual y estado permitido. |
| Reglas de negocio | Alta musical solo DIRECTOR/SOLISTA por ADMIN; versión optimista; baja lógica y revocación al suspender; conserva acceso administrativo. |
| Errores controlados | 400 entradas; 404 usuario; 409 correo, versión o estado administrativo. |
| Estado de implementación | Implementado localmente |
| Evidencia disponible | [informe de integración local](docs/integracion_android.md); [resumen de persistencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json); sin suite JUnit backend específica acreditada; [fuente original](backend/src/main/java/com/santacecilia/api/service/UsuarioService.java#L16) |

## 4 DTOs y validaciones declaradas

Las anotaciones siguientes proceden de los records declarados. @Valid en el Controller activa Bean Validation sobre el cuerpo; las comprobaciones entre campos, roles, horarios, vigencia y estado se completan en Services. Los records de salida no se interpretan como entradas validadas.

### ApiResponse

[ApiResponse](backend/src/main/java/com/santacecilia/api/dto/ApiResponse.java#L2)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| data | T | Sin anotación Bean Validation en el componente |

### AuthDtos.Forgot

[AuthDtos.Forgot](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L11)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| correo | String | @NotBlank; @Email; @Size(max = 254) |

### AuthDtos.Login

[AuthDtos.Login](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L9)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| correo | String | @NotBlank; @Email; @Size(max = 254) |
| password | String | @NotBlank; @Size(max = 200) |

### AuthDtos.Mensaje

[AuthDtos.Mensaje](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L14)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| mensaje | String | Sin anotación Bean Validation en el componente |

### AuthDtos.Refresh

[AuthDtos.Refresh](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L10)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| refreshToken | String | @NotBlank; @Size(max = 160) |

### AuthDtos.Registro

[AuthDtos.Registro](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L6)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| nombres | String | @NotBlank; @Size(max = 100) |
| apellidos | String | @NotBlank; @Size(max = 120) |
| correo | String | @NotBlank; @Email; @Size(max = 254) |
| password | String | @StrongPassword |
| aceptaPrivacidad | Boolean | @NotNull; @AssertTrue |
| privacidadVersion | String | @NotBlank; @Size(max = 80); @Pattern(regexp = "[A-Za-z0-9._-]+") |

### AuthDtos.Reset

[AuthDtos.Reset](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L12)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| token | String | @NotBlank; @Size(max = 160) |
| nuevaPassword | String | @StrongPassword |

### AuthDtos.Tokens

[AuthDtos.Tokens](backend/src/main/java/com/santacecilia/api/dto/AuthDtos.java#L13)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| tokenType | String | Sin anotación Bean Validation en el componente |
| accessToken | String | Sin anotación Bean Validation en el componente |
| refreshToken | String | Sin anotación Bean Validation en el componente |
| expiresIn | long | Sin anotación Bean Validation en el componente |
| usuario | UsuarioResponse | Sin anotación Bean Validation en el componente |

### CambioConMotivo

[CambioConMotivo](backend/src/main/java/com/santacecilia/api/dto/CambioConMotivo.java#L3)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @PositiveOrZero |
| motivo | String | @NotBlank; @Size(min = 5, max = 1000) |

### ContratacionDtos.Aceptar

[ContratacionDtos.Aceptar](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L46)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| aceptaCondiciones | boolean | @AssertTrue |
| clave | String | @NotBlank; @Pattern(regexp = "[A-Za-z0-9_-]{16,100}") |

### ContratacionDtos.Bloquear

[ContratacionDtos.Bloquear](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L70)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| inicio | Instant | @NotNull |
| fin | Instant | @NotNull |
| motivo | String | @NotBlank; @Size(min = 5, max = 1000) |

### ContratacionDtos.Cambiar

[ContratacionDtos.Cambiar](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L51)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| accion | String | @NotBlank |
| motivo | String | @Size(max = 1000) |

### ContratacionDtos.Cotizar

[ContratacionDtos.Cotizar](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L30)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| inicio | Instant | @NotNull |
| fin | Instant | @NotNull |
| conceptos | List<@Valid Linea> | @NotEmpty; @Size(max = 15) |
| descuentoCentimos | long | @Min(0); @Max(100000000) |
| condiciones | String | @NotBlank; @Size(min = 10, max = 2000) |
| incluyePolitica | boolean | @AssertTrue |
| vigenteHasta | Instant | @NotNull |
| clave | String | @NotBlank; @Pattern(regexp = "[A-Za-z0-9_-]{16,100}") |

### ContratacionDtos.Franja

[ContratacionDtos.Franja](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L56)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| dia | int | @Min(1); @Max(7) |
| desde | LocalTime | @NotNull |
| hasta | String | @NotBlank; @Pattern(regexp = "(?:[01][0-9]&#124;2[0-3]):[0-5][0-9](?::[0-5][0-9])?&#124;24:00(?::00)?") |
| previoMin | int | @Min(0); @Max(1440) |
| posteriorMin | int | @Min(0); @Max(1440) |

### ContratacionDtos.Horarios

[ContratacionDtos.Horarios](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L67)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| franjas | List<@Valid Franja> | @NotNull; @Size(max = 28) |

### ContratacionDtos.Linea

[ContratacionDtos.Linea](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L25)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| concepto | String | @NotBlank; @Size(min = 2, max = 150) |
| cantidad | int | @Min(1); @Max(1000) |
| precioCentimos | long | @Min(0); @Max(100000000) |

### ContratacionDtos.Responder

[ContratacionDtos.Responder](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L41)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| accion | String | @NotBlank |
| motivo | String | @Size(max = 1000) |

### ContratacionDtos.Solicitar

[ContratacionDtos.Solicitar](backend/src/main/java/com/santacecilia/api/dto/ContratacionDtos.java#L12)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| servicioId | long | @Positive |
| inicio | Instant | @NotNull |
| fin | Instant | @NotNull |
| lugar | String | @NotBlank; @Size(min = 5, max = 250) |
| ciudad | String | @NotBlank; @Size(min = 2, max = 100) |
| tipoEvento | String | @NotBlank; @Size(min = 2, max = 100) |
| asistentes | Integer | @Min(1); @Max(100000) |
| preferencias | String | @Size(max = 1000) |
| requerimientos | String | @Size(max = 1000) |
| notas | String | @Size(max = 1500) |
| clave | String | @NotBlank; @Pattern(regexp = "[A-Za-z0-9_-]{16,100}") |

### Pagina

[Pagina](backend/src/main/java/com/santacecilia/api/dto/Pagina.java#L3)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| items | List<T> | Sin anotación Bean Validation en el componente |
| pagina | int | Sin anotación Bean Validation en el componente |
| tamano | int | Sin anotación Bean Validation en el componente |
| total | long | Sin anotación Bean Validation en el componente |

### PagoDirectoDtos.Cancelar

[PagoDirectoDtos.Cancelar](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L58)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |

### PagoDirectoDtos.Comprobante

[PagoDirectoDtos.Comprobante](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L33)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| operacion | String | @NotBlank; @Pattern(regexp = "[A-Za-z0-9-]{3,100}") |
| fecha | LocalDate | @NotNull |
| importeCentimos | long | @Min(1); @Max(100000000) |
| titularOrigen | String | @NotBlank; @Size(min = 2, max = 180) |
| imagenBase64 | String | @NotBlank; @Size(max = 2800000) |

### PagoDirectoDtos.ConfirmarDevolucion

[PagoDirectoDtos.ConfirmarDevolucion](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L69)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| operacion | String | @NotBlank; @Pattern(regexp = "[A-Za-z0-9-]{3,100}") |
| fecha | LocalDate | @NotNull |
| importeCentimos | long | @Min(1); @Max(100000000) |
| contrasteEnCuenta | boolean | @AssertTrue |
| imagenBase64 | String | @NotBlank; @Size(max = 2800000) |

### PagoDirectoDtos.Cuenta

[PagoDirectoDtos.Cuenta](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L10)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| titular | String | @NotBlank; @Size(min = 2, max = 180) |
| banco | String | @NotBlank; @Size(min = 2, max = 100) |
| telefono | String | @Pattern(regexp = "9[0-9]{8}") |
| numeroCuenta | String | @Pattern(regexp = "[0-9]{6,40}") |
| cci | String | @Pattern(regexp = "[0-9]{20}") |
| yape | boolean | Sin anotación Bean Validation en el componente |
| plin | boolean | Sin anotación Bean Validation en el componente |
| transferencia | boolean | Sin anotación Bean Validation en el componente |
| activo | boolean | Sin anotación Bean Validation en el componente |

### PagoDirectoDtos.Devolver

[PagoDirectoDtos.Devolver](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L60)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| importeCentimos | long | @Min(1); @Max(100000000) |
| motivo | String | @NotBlank; @Size(min = 5, max = 1000) |
| clave | String | @NotBlank; @Pattern(regexp = "[A-Za-z0-9_-]{16,100}") |

### PagoDirectoDtos.Iniciar

[PagoDirectoDtos.Iniciar](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L27)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| cuentaId | long | @Positive |
| metodo | String | @NotBlank |
| modalidad | String | @NotBlank |
| clave | String | @NotBlank; @Pattern(regexp = "[A-Za-z0-9_-]{16,100}") |

### PagoDirectoDtos.Revision

[PagoDirectoDtos.Revision](backend/src/main/java/com/santacecilia/api/dto/PagoDirectoDtos.java#L45)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @Min(0) |
| accion | String | @NotBlank |
| motivo | String | @Size(max = 1000) |
| contrasteEnCuenta | Boolean | Sin anotación Bean Validation en el componente |
| operacion | String | @Pattern(regexp = "[A-Za-z0-9-]{3,100}") |
| fecha | LocalDate | Sin anotación Bean Validation en el componente |
| importeCentimos | Long | @Min(0); @Max(100000000) |

### ServicioDtos.Cancion

[ServicioDtos.Cancion](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L16)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| titulo | String | @NotBlank; @Size(max = 180) |
| genero | String | @NotBlank; @Size(max = 80) |
| descripcion | String | @Size(max = 1000) |
| duracionSegundos | Integer | @Positive |
| orden | Integer | @PositiveOrZero |

### ServicioDtos.CancionResponse

[ServicioDtos.CancionResponse](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L23)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| id | long | Sin anotación Bean Validation en el componente |
| titulo | String | Sin anotación Bean Validation en el componente |
| genero | String | Sin anotación Bean Validation en el componente |
| descripcion | String | Sin anotación Bean Validation en el componente |
| duracionSegundos | Integer | Sin anotación Bean Validation en el componente |
| orden | int | Sin anotación Bean Validation en el componente |

### ServicioDtos.Catalogo

[ServicioDtos.Catalogo](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L19)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| completo | boolean | Sin anotación Bean Validation en el componente |
| data | List<Resumen> | Sin anotación Bean Validation en el componente |

### ServicioDtos.Detalle

[ServicioDtos.Detalle](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L20)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| id | long | Sin anotación Bean Validation en el componente |
| responsableId | long | Sin anotación Bean Validation en el componente |
| tipo | String | Sin anotación Bean Validation en el componente |
| nombre | String | Sin anotación Bean Validation en el componente |
| ciudad | String | Sin anotación Bean Validation en el componente |
| descripcionHistorica | String | Sin anotación Bean Validation en el componente |
| experiencia | String | Sin anotación Bean Validation en el componente |
| incluye | String | Sin anotación Bean Validation en el componente |
| tarifaCentimos | Long | Sin anotación Bean Validation en el componente |
| estadoPublicacion | String | Sin anotación Bean Validation en el componente |
| version | long | Sin anotación Bean Validation en el componente |
| generos | List<String> | Sin anotación Bean Validation en el componente |
| instrumentos | List<String> | Sin anotación Bean Validation en el componente |
| tiposEvento | List<String> | Sin anotación Bean Validation en el componente |
| repertorio | List<CancionResponse> | Sin anotación Bean Validation en el componente |

### ServicioDtos.Guardar

[ServicioDtos.Guardar](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L6)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| responsableId | Long | @NotNull; @Positive |
| tipo | String | @NotBlank; @Pattern(regexp = "BANDA&#124;SOLISTA") |
| nombre | String | @NotBlank; @Size(max = 160) |
| ciudad | String | @NotBlank; @Size(max = 100) |
| descripcionHistorica | String | @Size(max = 10000) |
| experiencia | String | @Size(max = 500) |
| incluye | String | @Size(max = 10000) |
| tarifaCentimos | Long | @PositiveOrZero; @Max(999999999999L) |
| generos | List<@NotBlank @Size(max = 80) String> | @NotNull; @Size(max = 30) |
| instrumentos | List<@NotBlank @Size(max = 80) String> | @NotNull; @Size(max = 40) |
| tiposEvento | List<@NotBlank @Size(max = 100) String> | @NotNull; @Size(max = 30) |
| version | Long | @PositiveOrZero |

### ServicioDtos.Publicacion

[ServicioDtos.Publicacion](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L14)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @PositiveOrZero |
| estado | String | @NotBlank |
| motivo | String | @Size(max = 1000) |

### ServicioDtos.Resumen

[ServicioDtos.Resumen](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L18)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| id | long | Sin anotación Bean Validation en el componente |
| nombre | String | Sin anotación Bean Validation en el componente |
| tipo | String | Sin anotación Bean Validation en el componente |
| ciudad | String | Sin anotación Bean Validation en el componente |
| tarifaCentimos | Long | Sin anotación Bean Validation en el componente |
| generos | List<String> | Sin anotación Bean Validation en el componente |
| instrumentos | List<String> | Sin anotación Bean Validation en el componente |

### ServicioDtos.Tarifa

[ServicioDtos.Tarifa](backend/src/main/java/com/santacecilia/api/dto/ServicioDtos.java#L15)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @PositiveOrZero |
| tarifaCentimos | Long | @PositiveOrZero; @Max(999999999999L) |

### UsuarioDtos.CrearMusico

[UsuarioDtos.CrearMusico](backend/src/main/java/com/santacecilia/api/dto/UsuarioDtos.java#L7)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| nombres | String | @NotBlank; @Size(max = 100) |
| apellidos | String | @NotBlank; @Size(max = 120) |
| correo | String | @NotBlank; @Email; @Size(max = 254) |
| password | String | @StrongPassword |
| rol | Rol | @NotNull |

### UsuarioDtos.Estado

[UsuarioDtos.Estado](backend/src/main/java/com/santacecilia/api/dto/UsuarioDtos.java#L12)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @PositiveOrZero |
| estado | String | @NotBlank |
| motivo | String | @NotBlank; @Size(min = 5, max = 1000) |

### UsuarioDtos.Perfil

[UsuarioDtos.Perfil](backend/src/main/java/com/santacecilia/api/dto/UsuarioDtos.java#L9)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| version | Long | @NotNull; @PositiveOrZero |
| nombres | String | @NotBlank; @Size(max = 100) |
| apellidos | String | @NotBlank; @Size(max = 120) |
| telefono | String | @Size(max = 24) |
| ciudad | String | @Size(max = 100) |
| biografia | String | @Size(max = 1000) |

### UsuarioResponse

[UsuarioResponse](backend/src/main/java/com/santacecilia/api/dto/UsuarioResponse.java#L3)

| Componente | Tipo Java | Anotaciones declaradas |
|---|---|---|
| id | Long | Sin anotación Bean Validation en el componente |
| nombres | String | Sin anotación Bean Validation en el componente |
| apellidos | String | Sin anotación Bean Validation en el componente |
| correo | String | Sin anotación Bean Validation en el componente |
| telefono | String | Sin anotación Bean Validation en el componente |
| ciudad | String | Sin anotación Bean Validation en el componente |
| biografia | String | Sin anotación Bean Validation en el componente |
| rol | Rol | Sin anotación Bean Validation en el componente |
| estado | String | Sin anotación Bean Validation en el componente |
| version | long | Sin anotación Bean Validation en el componente |

### Tipos internos de soporte

| Tipo anidado | Función | Fuente |
|---|---|---|
| com.santacecilia.api.security.RequestThrottle.Window | Ventana temporal y contador del limitador | [Java](backend/src/main/java/com/santacecilia/api/security/RequestThrottle.java#L10) |
| com.santacecilia.api.service.RecoveryService.Solicitada | Evento de recuperación; toString redactado | [Java](backend/src/main/java/com/santacecilia/api/service/RecoveryService.java#L17) |

Los accesores automáticos de record se distinguen de los métodos escritos a mano: la tabla muestra sus componentes. Las firmas completas declaradas se conservan en `Analisis/Clases_Metodos_Declarados.json`.

## 5 Endpoints REST implementados

Las rutas se reconstruyen con @RequestMapping de clase y @Get/Post/Put/Patch/DeleteMapping de método. No se agregan endpoints descritos solo como propuestas. La autorización combina SecurityConfig y comprobaciones del Service; por eso algunos accesos ajenos se ocultan con 404 en lugar de 403.

| Verbo | Ruta completa | Controller y método | DTO en firma | Delegación real | Autorización | HTTP de éxito declarado | Fuente |
|---|---|---|---|---|---|---|---|
| GET | `/api/v1/admin/servicios` | AdminServicioController.listar | ApiResponse, Pagina, ServicioDtos.Detalle | ServicioService.listar | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L14](backend/src/main/java/com/santacecilia/api/controller/AdminServicioController.java#L14) |
| POST | `/api/v1/admin/servicios` | AdminServicioController.crear | ApiResponse, ServicioDtos.Detalle, ServicioDtos.Guardar | ServicioService.crear | ADMINISTRADOR; SecurityConfig y controles del Service | 201 | [L15](backend/src/main/java/com/santacecilia/api/controller/AdminServicioController.java#L15) |
| PUT | `/api/v1/admin/servicios/{id}` | AdminServicioController.editar | ApiResponse, ServicioDtos.Detalle, ServicioDtos.Guardar | ServicioService.editar | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L16](backend/src/main/java/com/santacecilia/api/controller/AdminServicioController.java#L16) |
| POST | `/api/v1/admin/servicios/{id}/publicacion` | AdminServicioController.publicar | ApiResponse, ServicioDtos.Detalle, ServicioDtos.Publicacion | ServicioService.publicacion | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L17](backend/src/main/java/com/santacecilia/api/controller/AdminServicioController.java#L17) |
| DELETE | `/api/v1/admin/servicios/{id}` | AdminServicioController.retirar | ApiResponse, CambioConMotivo, ServicioDtos.Detalle | ServicioService.publicacion | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L18](backend/src/main/java/com/santacecilia/api/controller/AdminServicioController.java#L18) |
| GET | `/api/v1/admin/usuarios` | AdminUsuarioController.listar | ApiResponse, Pagina, UsuarioResponse | UsuarioService.listar | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L14](backend/src/main/java/com/santacecilia/api/controller/AdminUsuarioController.java#L14) |
| GET | `/api/v1/admin/usuarios/{id}` | AdminUsuarioController.obtener | ApiResponse, UsuarioResponse | UsuarioService.obtener | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L15](backend/src/main/java/com/santacecilia/api/controller/AdminUsuarioController.java#L15) |
| POST | `/api/v1/admin/usuarios` | AdminUsuarioController.crear | ApiResponse, UsuarioDtos.CrearMusico, UsuarioResponse | UsuarioService.crearMusico | ADMINISTRADOR; SecurityConfig y controles del Service | 201 | [L16](backend/src/main/java/com/santacecilia/api/controller/AdminUsuarioController.java#L16) |
| PUT | `/api/v1/admin/usuarios/{id}` | AdminUsuarioController.editar | ApiResponse, UsuarioDtos.Perfil, UsuarioResponse | UsuarioService.editarAdmin | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L17](backend/src/main/java/com/santacecilia/api/controller/AdminUsuarioController.java#L17) |
| PATCH | `/api/v1/admin/usuarios/{id}/estado` | AdminUsuarioController.estado | ApiResponse, UsuarioDtos.Estado, UsuarioResponse | UsuarioService.estado | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L18](backend/src/main/java/com/santacecilia/api/controller/AdminUsuarioController.java#L18) |
| DELETE | `/api/v1/admin/usuarios/{id}` | AdminUsuarioController.desactivar | ApiResponse, CambioConMotivo, UsuarioResponse | UsuarioService.estado | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L19](backend/src/main/java/com/santacecilia/api/controller/AdminUsuarioController.java#L19) |
| POST | `/api/v1/auth/register` | AuthController.register | ApiResponse, AuthDtos.Registro, UsuarioResponse | AuthService.registrar | Público; validación y límite de intentos | 201 | [L17](backend/src/main/java/com/santacecilia/api/controller/AuthController.java#L17) |
| POST | `/api/v1/auth/login` | AuthController.login | ApiResponse, AuthDtos.Login, AuthDtos.Tokens | AuthService.login | Público; validación y límite de intentos | 200 | [L19](backend/src/main/java/com/santacecilia/api/controller/AuthController.java#L19) |
| POST | `/api/v1/auth/refresh` | AuthController.refresh | ApiResponse, AuthDtos.Refresh, AuthDtos.Tokens | AuthService.refresh | Público; refresh válido en el cuerpo | 200 | [L20](backend/src/main/java/com/santacecilia/api/controller/AuthController.java#L20) |
| POST | `/api/v1/auth/logout` | AuthController.logout | Parámetros escalares, Map o sin DTO | AuthService.logout | Usuario autenticado y activo | 204 | [L21](backend/src/main/java/com/santacecilia/api/controller/AuthController.java#L21) |
| POST | `/api/v1/auth/forgot-password` | AuthController.forgot | ApiResponse, AuthDtos.Forgot, AuthDtos.Mensaje | RecoveryService.solicitar | Público; validación y límite de intentos | 202 | [L23](backend/src/main/java/com/santacecilia/api/controller/AuthController.java#L23) |
| POST | `/api/v1/auth/reset-password` | AuthController.reset | AuthDtos.Reset | RecoveryService.restablecer | Público; token de recuperación válido | 204 | [L25](backend/src/main/java/com/santacecilia/api/controller/AuthController.java#L25) |
| POST | `/api/v1/solicitudes` | ContratacionController.solicitar | ApiResponse, ContratacionDtos.Solicitar | ContratacionService.solicitar | CLIENTE; en respuesta/aceptación, cliente original | 200 | [L29](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L29) |
| GET | `/api/v1/solicitudes` | ContratacionController.solicitudes | ApiResponse | ContratacionService.listado | Usuario autenticado; datos de sus operaciones, ADMIN global | 200 | [L35](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L35) |
| GET | `/api/v1/solicitudes/{id}` | ContratacionController.solicitud | ApiResponse | ContratacionService.detalleSolicitud | Usuario autenticado; datos de sus operaciones, ADMIN global | 200 | [L45](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L45) |
| POST | `/api/v1/solicitudes/{id}/estado` | ContratacionController.solicitudEstado | ApiResponse, ContratacionDtos.Cambiar | ContratacionService.cambiarSolicitud | Cliente cancela; proveedor revisa/rechaza; no se responde por otros actores | 200 | [L51](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L51) |
| POST | `/api/v1/solicitudes/{id}/cotizaciones` | ContratacionController.cotizar | ApiResponse, ContratacionDtos.Cotizar | ContratacionService.cotizar | Proveedor original de la solicitud | 200 | [L59](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L59) |
| POST | `/api/v1/solicitudes/{id}/cotizaciones/{quote}/respuesta` | ContratacionController.responder | ApiResponse, ContratacionDtos.Responder | ContratacionService.responder | CLIENTE; en respuesta/aceptación, cliente original | 200 | [L67](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L67) |
| POST | `/api/v1/solicitudes/{id}/cotizaciones/{quote}/aceptacion` | ContratacionController.aceptar | ApiResponse, ContratacionDtos.Aceptar | ContratacionService.aceptar | CLIENTE; en respuesta/aceptación, cliente original | 200 | [L76](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L76) |
| GET | `/api/v1/contratos` | ContratacionController.contratos | ApiResponse | ContratacionService.listado | Usuario autenticado; datos de sus operaciones, ADMIN global | 200 | [L85](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L85) |
| GET | `/api/v1/contratos/{id}` | ContratacionController.contrato | ApiResponse | ContratacionService.detalleContrato | Usuario autenticado; datos de sus operaciones, ADMIN global | 200 | [L95](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L95) |
| POST | `/api/v1/contratos/{id}/estado` | ContratacionController.contratoEstado | ApiResponse, ContratacionDtos.Cambiar | ContratacionService.cambiarContrato | CANCELAR: actores/ADMIN; FINALIZAR: proveedor/ADMIN | 200 | [L101](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L101) |
| GET | `/api/v1/servicios/{id}/disponibilidad` | ContratacionController.disponible | ApiResponse | ContratacionService.agenda | Público si publicado y responsable activo; propietario/ADMIN en otro estado | 200 | [L109](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L109) |
| GET | `/api/v1/servicios/{id}/agenda` | ContratacionController.agenda | ApiResponse | ContratacionService.agenda | Propietario del servicio o ADMIN | 200 | [L118](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L118) |
| PUT | `/api/v1/servicios/{id}/horarios` | ContratacionController.horarios | ApiResponse, ContratacionDtos.Horarios | ContratacionService.horarios | Propietario del servicio o ADMIN | 200 | [L127](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L127) |
| POST | `/api/v1/servicios/{id}/bloqueos` | ContratacionController.bloquear | ApiResponse, ContratacionDtos.Bloquear | ContratacionService.bloquear | Propietario del servicio o ADMIN | 200 | [L135](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L135) |
| DELETE | `/api/v1/servicios/{id}/bloqueos/{block}` | ContratacionController.desbloquear | Parámetros escalares, Map o sin DTO | ContratacionService.quitarBloqueo | Propietario del servicio o ADMIN | 200 | [L143](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L143) |
| GET | `/api/v1/mi-resumen` | ContratacionController.resumen | ApiResponse | ContratacionService.resumen | Usuario autenticado; datos de sus operaciones, ADMIN global | 200 | [L151](backend/src/main/java/com/santacecilia/api/controller/ContratacionController.java#L151) |
| GET | `/api/v1/health` | EstadoController.estado | ApiResponse | Consulta de salud JdbcTemplate | Público | 200 | [L10](backend/src/main/java/com/santacecilia/api/controller/EstadoController.java#L10) |
| GET | `/api/v1/admin/cuentas-cobro` | PagoDirectoController.cuentas | ApiResponse | PagoDirectoService.cuentas | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L26](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L26) |
| POST | `/api/v1/admin/cuentas-cobro` | PagoDirectoController.cuenta | ApiResponse, PagoDirectoDtos.Cuenta | PagoDirectoService.guardarCuenta | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L31](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L31) |
| PUT | `/api/v1/admin/cuentas-cobro/{id}` | PagoDirectoController.cuenta | ApiResponse, PagoDirectoDtos.Cuenta | PagoDirectoService.guardarCuenta | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L37](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L37) |
| GET | `/api/v1/contratos/{id}/pagos` | PagoDirectoController.contrato | ApiResponse | PagoDirectoService.resumen | Cliente/proveedor del contrato o ADMIN | 200 | [L45](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L45) |
| POST | `/api/v1/contratos/{id}/pagos` | PagoDirectoController.iniciar | ApiResponse, PagoDirectoDtos.Iniciar | PagoDirectoService.iniciar | CLIENTE dueño del contrato | 200 | [L51](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L51) |
| GET | `/api/v1/pagos` | PagoDirectoController.listar | ApiResponse | PagoDirectoService.listar | Cliente/proveedor del contrato o ADMIN | 200 | [L59](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L59) |
| GET | `/api/v1/pagos/{id}` | PagoDirectoController.pago | ApiResponse | PagoDirectoService.detalle | Cliente/proveedor del contrato o ADMIN | 200 | [L67](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L67) |
| PUT | `/api/v1/pagos/{id}/comprobante` | PagoDirectoController.reportar | ApiResponse, PagoDirectoDtos.Comprobante | PagoDirectoService.reportar | CLIENTE dueño del contrato | 200 | [L72](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L72) |
| POST | `/api/v1/pagos/{id}/cancelacion` | PagoDirectoController.cancelar | ApiResponse, PagoDirectoDtos.Cancelar | PagoDirectoService.cancelar | CLIENTE dueño del contrato | 200 | [L80](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L80) |
| GET | `/api/v1/pagos/{id}/comprobante` | PagoDirectoController.imagen | ApiResponse | PagoDirectoService.comprobante | Cliente/proveedor del contrato o ADMIN | 200 | [L88](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L88) |
| POST | `/api/v1/admin/pagos/{id}/revision` | PagoDirectoController.revision | ApiResponse, PagoDirectoDtos.Revision | PagoDirectoService.revisar | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L93](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L93) |
| POST | `/api/v1/admin/pagos/{id}/reembolsos` | PagoDirectoController.devolver | ApiResponse, PagoDirectoDtos.Devolver | PagoDirectoService.devolver | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L101](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L101) |
| POST | `/api/v1/admin/reembolsos/{id}/confirmacion` | PagoDirectoController.confirmar | ApiResponse, PagoDirectoDtos.ConfirmarDevolucion | PagoDirectoService.confirmarDevolucion | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L109](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L109) |
| GET | `/api/v1/reembolsos/{id}/comprobante` | PagoDirectoController.imagenDevolucion | ApiResponse | PagoDirectoService.comprobante | Cliente/proveedor del contrato o ADMIN | 200 | [L117](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L117) |
| GET | `/api/v1/reembolsos/{id}` | PagoDirectoController.reembolso | ApiResponse | PagoDirectoService.detalleReembolso | Cliente/proveedor del contrato o ADMIN | 200 | [L123](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L123) |
| POST | `/api/v1/admin/reembolsos/{id}/rechazo` | PagoDirectoController.rechazo | ApiResponse, PagoDirectoDtos.Revision | PagoDirectoService.rechazarDevolucion | ADMINISTRADOR; SecurityConfig y controles del Service | 200 | [L129](backend/src/main/java/com/santacecilia/api/controller/PagoDirectoController.java#L129) |
| GET | `/api/v1/servicios` | ServicioController.catalogo | ServicioDtos.Catalogo | ServicioService.catalogo | Público; solo servicios publicados con responsable activo | 200 | [L15](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L15) |
| GET | `/api/v1/servicios/{id}` | ServicioController.detalle | ApiResponse, ServicioDtos.Detalle | ServicioService.obtener | Público si publicado; propietario/ADMIN en otros estados | 200 | [L19](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L19) |
| GET | `/api/v1/mis-servicios` | ServicioController.propios | ApiResponse, ServicioDtos.Detalle | ServicioService.propios | DIRECTOR/SOLISTA; servicios asignados | 200 | [L20](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L20) |
| PATCH | `/api/v1/servicios/{id}/tarifa` | ServicioController.tarifa | ApiResponse, ServicioDtos.Detalle, ServicioDtos.Tarifa | ServicioService.tarifa | ADMIN o DIRECTOR/SOLISTA propietario | 200 | [L21](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L21) |
| POST | `/api/v1/servicios/{id}/repertorio` | ServicioController.agregar | ApiResponse, ServicioDtos.Cancion, ServicioDtos.CancionResponse | ServicioService.agregarCancion | ADMIN o DIRECTOR/SOLISTA propietario | 201 | [L22](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L22) |
| PUT | `/api/v1/servicios/{id}/repertorio/{cancion}` | ServicioController.editar | ServicioDtos.Cancion | ServicioService.editarCancion | ADMIN o DIRECTOR/SOLISTA propietario | 204 | [L24](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L24) |
| DELETE | `/api/v1/servicios/{id}/repertorio/{cancion}` | ServicioController.retirar | Parámetros escalares, Map o sin DTO | ServicioService.retirarCancion | ADMIN o DIRECTOR/SOLISTA propietario | 204 | [L26](backend/src/main/java/com/santacecilia/api/controller/ServicioController.java#L26) |
| GET | `/api/v1/me` | UsuarioController.me | ApiResponse, UsuarioResponse | UsuarioService.propio | Usuario autenticado; perfil propio | 200 | [L13](backend/src/main/java/com/santacecilia/api/controller/UsuarioController.java#L13) |
| PATCH | `/api/v1/me` | UsuarioController.perfil | ApiResponse, UsuarioDtos.Perfil, UsuarioResponse | UsuarioService.editarPropio | Usuario autenticado; perfil propio | 200 | [L14](backend/src/main/java/com/santacecilia/api/controller/UsuarioController.java#L14) |

Los códigos de éxito son el valor por defecto o @ResponseStatus del método. Un 200 puede contener un resultado de negocio EN_REVISION; no significa que se haya aplicado un pago o creado una reserva. Los nombres, valores por defecto y anotaciones de parámetros de consulta están conservados en `Analisis/Endpoints_Implementados.json`.

## 6 Autenticación y autorización

AuthController delega el registro y sesiones en AuthService. El registro público fija CLIENTE. Las altas musicales solo permiten DIRECTOR o SOLISTA desde administración. SecurityConfig restringe /api/v1/admin/** a ADMINISTRADOR, deja públicas las rutas explícitas de acceso, catálogo, disponibilidad y salud y exige autenticación para el resto. ServicioService y UsuarioService complementan con @PreAuthorize y controles de propietario. ContratacionService y PagoDirectoService validan directamente el actor y su relación con la operación.

Se usa bcrypt con coste 12 y tokens opacos generados por SecureRandom, no JWT. La API HTTP es stateless, pero la validez de tokens, sesión, familia y cuenta se consulta en MySQL. AuthService.refresh conserva la revocación por reutilización con @Transactional(noRollbackFor=TokenRejectedException.class). Suspensión, cierre y restablecimiento revocan familias.

La recuperación usa un evento después del commit y envío asíncrono. Sin SMTP/configuración disponible responde 503. Una respuesta 202 no acredita que el correo se haya entregado. El limitador de intentos es local a la instancia; su coordinación entre réplicas queda pendiente.

## 7 Reglas de solicitudes cotizaciones y contratos

| Operación | Método real | Reglas y resultado |
|---|---|---|
| Solicitar | ContratacionService.solicitar | CLIENTE, servicio publicado y responsable activo; intervalo futuro <=24 h y cobertura de franjas/márgenes. Clave/huella devuelve mismo registro o 409 si cambia la entrada. No ocupa agenda. |
| Revisar/rechazar/cancelar solicitud | ContratacionService.cambiarSolicitud | Cliente cancela; proveedor revisa o rechaza. Motivo cuando corresponde; solicitud abierta y versión actual. |
| Cotizar | ContratacionService.cotizar | Proveedor original, hasta 15 conceptos con cantidades enteras, precios/descuento exactos y total positivo <=100000000 céntimos. Vigencia futura hasta el inicio. Conserva versiones y política del servidor. |
| Responder propuesta | ContratacionService.responder | Cliente original solicita CAMBIOS o RECHAZAR sobre propuesta vigente; no crea contrato. |
| Aceptar | ContratacionService.aceptar | Última propuesta ENVIADA no vencida y consentimiento. Genera snapshot con actores, propuesta, recursos y evento; contrato PENDIENTE_PAGO. No reserva ni retiene. |
| Confirmar contrato y reservar | PagoDirectoService.revisar | Solo al aplicar el primer ingreso verificado y compatible; crea reserva y ocupaciones con los recursos congelados del contrato. No hay endpoint independiente de confirmación manual. |
| Cancelar/finalizar | ContratacionService.cambiarContrato | Requiere CONFIRMADO. Cancelar exige motivo, conserva dinero/historial y libera ocupaciones. Finalizar exige proveedor/ADMIN y hora de servidor posterior al fin. No realiza reembolso externo. |

## 8 Disponibilidad exclusión y reservas duplicadas

ContratacionRepository.recursos resuelve servicio, responsable e integrantes vinculados ACEPTADO activos. lock ordena sus IDs y ejecuta SELECT ... FOR UPDATE sobre filas estables. libre busca ocupaciones activas y no vencidas con inicioExistente < finNuevo y finExistente > inicioNuevo. Los intervalos contiguos pueden ser compatibles, considerando los márgenes.

ContratacionService.atencion une franjas locales America/Lima y calcula márgenes. La consulta pública de agenda solo expone horas/estado; motivos privados requieren propietario o ADMIN. Los bloqueos retirados liberan el conjunto original de ocupaciones, incluso si cambió el elenco. El snapshot contractual conserva los recursos aceptados.

La unicidad de una reserva por contrato y las claves idempotentes complementan el bloqueo. No existe una restricción UNIQUE que por sí sola excluya todo intervalo superpuesto. La garantía exige pasar por los Services transaccionales; SQL arbitrario que omita ese protocolo puede vulnerarla. El documento original de protocolo contiene referencias históricas a retenciones/pasarela: son diseño previo, no una función actual de checkout.

## 9 Pagos directos comprobantes conciliación y devoluciones

| Hecho | Implementación real | Efecto |
|---|---|---|
| Instrucciones de pago | PagoDirectoService.iniciar | Valida cliente, cuenta/medio habilitados, estado y saldo. SALDO_COMPLETO o MITAD_SALDO=(saldo+1)/2. Guarda destino histórico; no cobra ni reserva. |
| Comprobante del cliente | PagoDirectoService.reportar y ComprobanteImagenService.normalizar | Imagen autorizada y recodificada; huella de datos/imagen. Estado PROCESANDO, sin abono ni reserva. |
| Contraste administrativo | PagoDirectoService.revisar | ADMIN confirma contrasteEnCuenta y registra operación, fecha e importe que verificó fuera del sistema. Puede rechazar con motivo. No hay consulta a bancos. |
| Aplicación y primera reserva | PagoDirectoService.revisar | Si son compatibles importe, saldo, evento y agenda, aplica APROBADO y en la primera aplicación crea reserva/ocupaciones y contrato CONFIRMADO, en la misma transacción. |
| Ingreso incompatible | PagoDirectoService.revisar | Conserva movimiento contrastado y estado EN_REVISION sin abonar/reservar ante importe diferente, conflicto, evento tardío o estado no aplicable. |
| Solicitar devolución | PagoDirectoService.devolver | Ingreso previamente contrastado. Para abono aplicado, contrato cancelado. Importe limitado al ingreso menos devoluciones comprometidas. No transfiere dinero. |
| Confirmar devolución externa | PagoDirectoService.confirmarDevolucion | ADMIN aporta operación, fecha, importe, imagen y contraste. Registra movimiento e idempotencia, actualiza estado y saldo, y resuelve incidencia si procede. |
| Anular solicitud aún pendiente | PagoDirectoService.rechazarDevolucion | Solo solicitud PENDIENTE, motivo y versión; no revierte una transferencia ya realizada. |

**No se implementaron pasarela financiera, cobro automático, checkout comercial, webhooks bancarios ni reembolso bancario automático.** La automatización implementada es la aplicación contable y creación de reserva después de la conciliación humana autorizada. Una captura del pagador no se considera prueba suficiente del ingreso.

## 10 Transacciones e idempotencia

| Componente | Mecanismo real | Operaciones/condición |
|---|---|---|
| AuthService, RecoveryService, UsuarioService, ServicioService | @Transactional; readOnly en consultas declaradas; bloqueos JPA cuando corresponde | AuthService.refresh exceptúa rollback de TokenRejectedException para confirmar la revocación. |
| ContratacionService | TransactionTemplate READ_COMMITTED y write(Supplier<T>) | Hasta tres intentos ante PessimisticLockingFailureException. Clave y SHA-256 de solicitud/cotización/aceptación; versiones para otras mutaciones. |
| PagoDirectoService | TransactionTemplate READ_COMMITTED; orden recursos → contrato → pago/devolución | Claves/huellas de inicio, reporte, revisión, solicitud y confirmación de devolución. Misma entrada devuelve resultado; entrada distinta con clave/huella previa produce conflicto. |
| PagoAvisosService | @Transactional, FOR UPDATE SKIP LOCKED y scheduler | Notificaciones y estado ENVIADO de outbox se comprometen juntos, sin servicios bancarios o de mensajería externa. |
| Persistencia SQL | UNIQUE, FK, CHECK y triggers versionados | Unicidad de movimiento por cuenta/fecha/operación, reserva por contrato y coherencia contractual. No sustituye autorización ni bloqueo de intervalos. |

No todas las operaciones poseen clave de idempotencia: altas de cuentas/servicios y configuración de horarios tienen sus validaciones, restricciones y/o versión. No se presenta toda la API como idempotente. Las llamadas financieras externas no existen y no se mantienen bloqueos mientras el cliente paga fuera de la app.

## 11 Excepciones y manejo HTTP

| HTTP | Fuente real | Tratamiento |
|---|---|---|
| 400 | ApiException.invalid; GlobalExceptionHandler.validation/invalid; RecoveryService | Validación de campos, formato, parámetros y enlace de recuperación. |
| 401 | SecurityConfig, BearerAuthenticationFilter, ApiException.unauthenticated, TokenRejectedException | Falta o invalidez de acceso; revocación confirmada cuando hay reutilización de refresh. |
| 403 | SecurityConfig y GlobalExceptionHandler.denied | Rol insuficiente en seguridad de ruta/método. |
| 404 | ApiException.notFound y GlobalExceptionHandler.missing | Ausencia de recurso o acceso ajeno ocultado por el Service. |
| 405 | GlobalExceptionHandler.method | Verbo no disponible para la ruta. |
| 409 | ApiException.conflict; GlobalExceptionHandler.integrity/stale | Versión, restricción, duplicado, vigencia o superposición incompatible. |
| 413 | PagosPrivadosFilter | sendError cuando Content-Length supera 3 MB; no garantiza cuerpo ApiError uniforme. |
| 429 | RequestThrottle y ComprobanteImagenService | Límite de intentos o de imágenes concurrentes. |
| 500 | GlobalExceptionHandler.unexpected | Mensaje seguro; log limitado a correlación y tipo de excepción. |
| 503 | RecoveryService.solicitar | Correo de recuperación no configurado/disponible. |

El cuerpo habitual es ApiError(code,message,fieldErrors,correlationId). Los fallos de filtros pueden quedar fuera de @RestControllerAdvice. La incidencia de un ingreso ya contrastado se conserva como resultado de negocio EN_REVISION y no debe confundirse con un error HTTP que haga perder el movimiento.

## 12 Pruebas y resultados verificables incluidos

| Comprobación histórica | Resultado conservado | Evidencia incluida | Límite |
|---|---|---|---|
| JVM Android | 8 ApiConfigTest + 3 MoneyUtilsTest; 0 fallos/errores | [XML saneados](Evidencias/Pruebas_JVM) y fuentes app/src/test | Son pruebas Android/JVM, no de Services Spring Boot. No se ejecutaron de nuevo. |
| Lint Android | 0 errores y 30 advertencias en el resumen final | [texto conservado](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/resumen_lint.txt) | No prueba por sí solo reglas del backend; reportes antiguos pueden tener otros conteos. |
| MySQL V001–V004 | 31 comprobaciones SQL históricas | [JSON histórico](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/mysql_verificacion_historica_v004.json) | Corte de 30 tablas; no una nueva suite de las 36 tablas vigentes. |
| Contratación/agenda | 15 comprobaciones enumeradas y resumen de 11 de concurrencia; informe describe 26 agrupadas | [JSON](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/contratacion_comprobaciones.json); [concurrencia](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/contratacion_concurrencia.json) | Los 11 casos no están enumerados individualmente en ese auxiliar. La fecha de evento del JSON no es fecha de ejecución. |
| Pagos directos | 28 comprobaciones agrupadas registradas | [JSON histórico](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/pagos_comprobaciones_sinteticas.json) | Datos e ingresos sintéticos; no sandbox bancario ni transferencias reales. |
| Registro Android | 1 regresión instrumentada aprobada documentada | [resumen](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/regresion_registro.txt) y fuente AccesoFragmentTest | Resumen del resultado observado, sin reporte XML independiente de esa ejecución. |
| Room y mapper Android | 2 pruebas Room y 4 de JSON compiladas | [fuentes existentes](app/src/androidTest) | No hay evidencia aportada de ejecución de esos seis casos; no se marcan aprobados. |
| Persistencia y arranque | API, administrador y persistencia true en la comprobación guardada | [resumen](ENTREGABLES_UNIDAD_III/11_Evidencias_Iteraciones/verificacion_arranque.json) | 37:1:007 describe el momento de prueba; no cuenta usuarios actuales. |
| Recorridos visuales | 7 capturas del flujo de negocio recogidas | [PNG](ENTREGABLES_UNIDAD_III/06_Interfaces_Funcionales/capturas) | Capturas históricas de datos sintéticos; no sustituyen logs por caso ni pruebas de producción. |

**No se encontró una suite `backend/src/test` ni reportes `backend/build/test-results` que acrediten pruebas JUnit del backend.** El build del backend inspeccionado no declara dependencias de test. Las verificaciones HTTP/MySQL de las etapas 6–7 son comprobaciones técnicas documentadas y resultados auxiliares, no una cobertura unitaria certificada. No se inventan nombres de métodos de prueba para los casos agrupados.

En esta recopilación se analizaron fuentes, XML/JSON existentes, nombres y enlaces, integridad de archivos y contenido del ZIP. No se levantaron servidores, no se consultaron filas de usuarios/pagos, no se realizaron transacciones ni se reejecutaron suites funcionales.

## 13 Funciones incompletas y alcance excluido

| Función | Estado real | Qué falta o condición |
|---|---|---|
| Bandeja visible de notificaciones | Persistencia/outbox implementados | No hay Controller de consulta de avisos para completar la experiencia del usuario. |
| Imágenes e integrantes del servicio | Estructuras y contenido parcial | No hay API completa de galería, invitaciones y sustituciones. El visor de comprobantes de pago es otro módulo. |
| Filtros analíticos e indicadores | Búsqueda/estado y resumen básico existentes | Faltan todos los filtros por periodo/proveedor y series diarias/semanales/mensuales. |
| Consulta de auditoría | Registro implementado | No hay endpoint general de consulta administrativa de auditoría. |
| Exportación de registros y constancia | Pendiente | No se encontró Controller de exportaciones ni descarga de constancia contractual. |
| Valoración/encuesta RF-68 | Pendiente | La existencia de estructuras no acredita un recorrido implementado ni un instrumento validado. |
| SMTP externo | Condicionado | Necesita configuración y verificación externa; solo existe evidencia histórica local. |
| Pasarela/webhooks/cobro automático | No implementado; fuera de la modalidad directa acordada | No atribuir al sistema una API bancaria ni prometer esa función como ya conectada. |
| Producción y validación RNF | Pendiente de acreditación | Firma/distribución, SMTP, operación de servidor, respaldo/restauración, seguridad, rendimiento y validación con usuarios. |

## 14 Correspondencia entre documentación y código

backend/API.md contiene secciones históricas anteriores a los Controllers de contratación y pagos; sus ampliaciones de etapas 6–7 describen la modalidad actual. database/protocolo_agenda.md también conserva lenguaje de futuro y diseño previo de checkout/retenciones. Se incluyen sin reescribir sus fuentes y esta recopilación no los convierte en prueba de una pasarela existente.

El catálogo de 59 endpoints y las fichas de clase de este inventario se basan en el código actual. Los registros contractuales y financieros se procesan con ContratacionRepository y Map/JDBC; no se inventan clases ContratoService, AgendaService, PagoRepository o WebhookController.

## 15 Privacidad integridad y contenido del paquete

Se incluyen fuentes y contratos de datos, no valores de credenciales o filas de producción. No se copian .env, claves privadas, almacenes de certificados, bases persistentes, sesiones cifradas, archivos .local, logs operativos completos o capturas de personas reales. Los XML JVM omiten hostname y datos de entorno. Las únicas imágenes recopiladas proceden del conjunto histórico identificado como sintético.

El manifiesto lista cada archivo, su ruta original relativa, su categoría y sus hashes. Distingue copias literales de copias saneadas y resúmenes derivados. Las fuentes Java se comprueban completas y sin cambios. La revisión de integridad compara los archivos originales y el índice Git antes y después, sin add, commit, push, merge ni cambios de aplicación.
